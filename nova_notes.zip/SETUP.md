# Nova Notes - Setup Guide

## Prerequisites
- Flutter SDK >= 3.16.0
- Dart SDK >= 3.2.0
- Android Studio or Xcode

## Quick Start

```bash
git clone https://github.com/your-org/nova-notes.git
cd nova-notes
make setup
```

## Firebase Configuration

1. Create a Firebase project at https://console.firebase.google.com
2. Add Android and iOS apps
3. Download `google-services.json` (Android) and `GoogleService-Info.plist` (iOS)
4. Place them in the appropriate platform directories

## Run the App

```bash
flutter run
```

## Development Commands

```bash
make setup      # Install dependencies
make generate   # Generate code
make test       # Run tests
make analyze    # Analyze code
make format     # Format code
make run        # Run app
```
