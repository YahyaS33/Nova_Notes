# Nova Notes

<p align="center">
  <img src="assets/icons/app_icon.png" width="120" alt="Nova Notes Logo">
</p>

<h1 align="center">Nova Notes</h1>
<p align="center"><strong>Premium All-in-One Productivity Ecosystem</strong></p>

<p align="center">
  <a href="#"><img src="https://img.shields.io/badge/Flutter-3.16+-blue.svg?logo=flutter" alt="Flutter"></a>
  <a href="#"><img src="https://img.shields.io/badge/Dart-3.2+-blue.svg?logo=dart" alt="Dart"></a>
  <a href="#"><img src="https://img.shields.io/badge/Firebase-Cloud%20Firestore-orange.svg?logo=firebase" alt="Firebase"></a>
  <a href="#"><img src="https://img.shields.io/badge/License-MIT-green.svg" alt="License"></a>
</p>

---

## Think. Plan. Create.

Nova Notes is a **production-grade**, cross-platform productivity application that combines Smart Notes, Calendar, Tasks, Daily Planner, and an AI Productivity Assistant into one seamless, beautiful experience.

Built with startup-grade engineering standards, Nova Notes delivers:
- **Apple-level simplicity** in every interaction
- **Notion-level flexibility** for content organization
- **TickTick-level speed** for task management
- **Linear-level elegance** in design and motion

---

## Features

### Smart Notes System
- Fast note-taking with rich editor
- Markdown support & formatting
- Folders, tags, and smart organization
- Pin important notes
- Full-text search with instant results
- AI-powered summaries
- AI task extraction from notes
- Attachments support
- Offline-first with auto-sync
- Beautiful writing interface

### Calendar System
- Day / Week / Month views
- Agenda layout
- Smart reminders & notifications
- Drag-and-drop scheduling
- Time blocking support
- Color-coded events
- Google Calendar sync-ready
- Apple Calendar sync-ready
- Quick event creation

### Tasks System
- Smart task management
- Priority levels (Urgent, High, Medium, Low)
- Due dates & reminders
- Recurring tasks
- Kanban board view
- Focus sessions & Pomodoro timer
- Productivity tracking
- Daily goals
- Progress statistics

### AI Productivity Assistant
- Summarize notes instantly
- Generate tasks from notes
- Smart daily planning suggestions
- Intelligent reminders
- Daily productivity analysis
- Focus recommendations
- Natural language interaction

### Design System
- Minimal Premium aesthetic
- Dark mode first (with light mode support)
- Subtle glassmorphism effects
- Soft shadows & rounded corners
- Smooth 60fps transitions
- Premium spacing & typography
- Inter, SF Pro, IBM Plex Sans Arabic fonts
- Electric blue & deep purple accents
- Calm, productive gradients

---

## Tech Stack

| Layer | Technology |
|-------|-----------|
| **Framework** | Flutter 3.16+ |
| **Language** | Dart 3.2+ |
| **State Management** | flutter_bloc (BLoC Pattern) |
| **Navigation** | go_router |
| **Dependency Injection** | get_it + injectable |
| **Backend** | Firebase (Auth, Firestore, Messaging, Analytics) |
| **Local DB** | Hive + SQLite |
| **Networking** | Dio + Retrofit |
| **AI** | Google Generative AI |
| **Animations** | flutter_animate + lottie |
| **UI** | Material 3 + Custom Design System |

---

## Architecture

Nova Notes follows **Clean Architecture** with a clear separation of concerns:

```
lib/
├── core/                    # Shared core functionality
│   ├── constants/           # App constants & configuration
│   ├── errors/              # Failure classes
│   ├── navigation/          # Router configuration
│   ├── services/            # Shared services (connectivity, notifications)
│   ├── theme/               # Design system & theming
│   ├── usecases/            # Base use case classes
│   └── utils/               # Extensions & utilities
│
├── features/                # Feature modules
│   ├── auth/               # Authentication
│   ├── notes/              # Smart Notes
│   ├── calendar/           # Calendar System
│   ├── tasks/              # Task Management
│   ├── ai/                 # AI Assistant
│   └── dashboard/          # Dashboard & Home
│
├── shared/                 # Shared UI components
│   ├── widgets/            # Reusable widgets
│   └── animations/         # Animation presets
│
└── main.dart              # App entry point
```

### Clean Architecture Layers

Each feature follows the **Data → Domain → Presentation** pattern:

- **Data Layer**: Models, datasources (remote/local), repository implementations
- **Domain Layer**: Entities, repository contracts, use cases
- **Presentation Layer**: BLoC state management, pages, widgets

---

## Getting Started

### Prerequisites

- Flutter SDK >= 3.16.0
- Dart SDK >= 3.2.0
- Android Studio / Xcode
- Firebase project (for backend features)

### Installation

```bash
# Clone the repository
git clone https://github.com/your-org/nova-notes.git
cd nova-notes

# Install dependencies
flutter pub get

# Generate code (JSON serializable, injectable, etc.)
flutter pub run build_runner build --delete-conflicting-outputs

# Run the app
flutter run
```

### Firebase Setup

1. Create a Firebase project at [console.firebase.google.com](https://console.firebase.google.com)
2. Add Android & iOS apps
3. Download `google-services.json` (Android) and `GoogleService-Info.plist` (iOS)
4. Place them in the appropriate platform directories
5. Enable Authentication, Firestore, and Cloud Messaging

---

## Development

### Code Generation

```bash
# Generate dependency injection
dart run build_runner build

# Watch for changes (continuous generation)
dart run build_runner watch
```

### Running Tests

```bash
# Unit tests
flutter test

# Integration tests
flutter test integration_test/

# With coverage
flutter test --coverage
```

### Building

```bash
# Android APK
flutter build apk --release

# Android App Bundle
flutter build appbundle --release

# iOS
flutter build ios --release

# Web
flutter build web --release
```

---

## Project Structure

```
nova_notes/
├── android/                 # Android platform code
├── ios/                     # iOS platform code
├── web/                     # Web platform code
├── macos/                   # macOS platform code
├── windows/                 # Windows platform code
├── linux/                   # Linux platform code
├── assets/                  # Static assets
│   ├── fonts/              # Custom fonts
│   ├── icons/              # App icons
│   ├── images/             # Images
│   └── animations/         # Lottie animations
├── lib/                     # Main source code
├── test/                    # Test files
│   ├── unit/               # Unit tests
│   ├── widget/             # Widget tests
│   └── integration/        # Integration tests
├── docs/                    # Documentation
│   ├── architecture/       # Architecture docs
│   ├── api/                # API documentation
│   └── design/             # Design system docs
├── .github/                 # GitHub workflows
├── fastlane/                # CI/CD automation
├── pubspec.yaml             # Dependencies
├── analysis_options.yaml    # Lint rules
└── README.md               # This file
```

---

## Design System

### Colors

| Token | Dark Mode | Light Mode |
|-------|-----------|------------|
| Background | `#0A0A0F` | `#F8F9FC` |
| Surface | `#12121A` | `#FFFFFF` |
| Primary | `#3B82F6` | `#3B82F6` |
| Secondary | `#7C3AED` | `#7C3AED` |
| Text Primary | `#F8FAFC` | `#0F172A` |
| Text Secondary | `#94A3B8` | `#475569` |

### Typography

- **Display**: Inter, 48sp, Weight 700
- **Headline**: Inter, 28sp, Weight 600
- **Title**: Inter, 18sp, Weight 600
- **Body**: Inter, 16sp, Weight 400
- **Label**: Inter, 14sp, Weight 500

---

## Roadmap

### MVP (v1.0.0)
- [x] Smart Notes with rich editor
- [x] Calendar with day/week/month views
- [x] Task management with priorities
- [x] Dashboard with productivity overview
- [x] AI Assistant integration
- [x] Focus mode / Pomodoro timer
- [x] Offline-first architecture
- [x] Firebase Authentication
- [x] Firestore cloud sync
- [x] Push notifications

### v1.1.0
- [ ] Google Calendar sync
- [ ] Apple Calendar sync
- [ ] Biometric authentication
- [ ] Widget support (Android/iOS)
- [ ] Deep linking
- [ ] Share extensions

### v1.2.0
- [ ] Team collaboration
- [ ] Real-time collaborative editing
- [ ] Advanced AI features
- [ ] Custom themes
- [ ] Desktop support (macOS, Windows, Linux)

### Future
- [ ] Web app full feature parity
- [ ] API for third-party integrations
- [ ] Plugin system
- [ ] White-label solution

---

## Contributing

We welcome contributions! Please read our [Contributing Guide](CONTRIBUTING.md) for details on:

- Code of Conduct
- Development workflow
- Pull request process
- Coding standards
- Testing requirements

### Quick Start for Contributors

```bash
# Fork and clone
git clone https://github.com/your-username/nova-notes.git

# Create feature branch
git checkout -b feature/your-feature-name

# Make changes and commit
git commit -m "feat: add your feature description"

# Push and create PR
git push origin feature/your-feature-name
```

---

## Team

Nova Notes is built by a passionate team of engineers and designers committed to creating the best productivity experience.

---

## License

Nova Notes is released under the [MIT License](LICENSE).

---

<p align="center">
  <strong>Made with precision. Built for productivity.</strong>
</p>

<p align="center">
  Nova Notes &copy; 2026
</p>
