# Nova Notes Architecture

## Overview

Nova Notes follows **Clean Architecture** principles combined with **BLoC (Business Logic Component)** pattern for state management. This document describes the architectural decisions, patterns, and conventions used throughout the application.

## Architecture Layers

```
┌─────────────────────────────────────────────────────────────┐
│                    PRESENTATION LAYER                          │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────┐  │
│  │   Pages     │  │   Widgets   │  │   BLoC / Cubit      │  │
│  │  (UI)       │  │  (UI)       │  │  (State Management) │  │
│  └─────────────┘  └─────────────┘  └─────────────────────┘  │
├─────────────────────────────────────────────────────────────┤
│                      DOMAIN LAYER                            │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────┐  │
│  │  Entities   │  │ Repositories│  │    Use Cases        │  │
│  │  (Models)   │  │  (Contracts)│  │  (Business Logic)   │  │
│  └─────────────┘  └─────────────┘  └─────────────────────┘  │
├─────────────────────────────────────────────────────────────┤
│                       DATA LAYER                             │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────┐  │
│  │   Models    │  │ Datasources │  │ Repositories        │  │
│  │  (DTOs)     │  │(Remote/Local│  │  (Implementations)  │  │
│  └─────────────┘  └─────────────┘  └─────────────────────┘  │
└─────────────────────────────────────────────────────────────┘
```

## Dependency Direction

Dependencies flow inward:
- **Presentation** depends on **Domain**
- **Data** depends on **Domain**
- **Domain** has no external dependencies

## Layer Responsibilities

### Domain Layer
- **Entities**: Pure business objects with no framework dependencies
- **Repository Contracts**: Abstract interfaces defining data operations
- **Use Cases**: Single-responsibility business logic operations

### Data Layer
- **Models**: Data transfer objects with JSON serialization
- **Remote Datasource**: Firebase Firestore operations
- **Local Datasource**: Hive/SQLite offline storage
- **Repository Implementation**: Concrete data operations with offline-first strategy

### Presentation Layer
- **Pages**: Full-screen UI components
- **Widgets**: Reusable UI components
- **BLoC**: State management with event-driven architecture

## State Management

### BLoC Pattern

```dart
// Event
abstract class NotesEvent {}
class LoadNotes extends NotesEvent {}

// State
abstract class NotesState {}
class NotesLoaded extends NotesState {
  final List<Note> notes;
  NotesLoaded(this.notes);
}

// BLoC
class NotesBloc extends Bloc<NotesEvent, NotesState> {
  NotesBloc() : super(NotesInitial()) {
    on<LoadNotes>(_onLoadNotes);
  }
}
```

### State Flow

```
User Action → Event → BLoC → Use Case → Repository → Data Source
                                              ↓
UI Update ← State ← BLoC ← Entity ← Repository ← Data Source
```

## Navigation

Using **go_router** for declarative, URL-based navigation:

```dart
final router = GoRouter(
  routes: [
    GoRoute(path: '/', builder: (_, __) => SplashPage()),
    GoRoute(path: '/dashboard', builder: (_, __) => DashboardPage()),
    GoRoute(
      path: '/notes/:id',
      builder: (context, state) => NoteDetailPage(
        id: state.pathParameters['id']!,
      ),
    ),
  ],
);
```

## Dependency Injection

Using **get_it** with **injectable** for compile-time dependency injection:

```dart
@module
abstract class RegisterModule {
  @singleton
  FirebaseFirestore get firestore => FirebaseFirestore.instance;
}

@Injectable(as: NoteRepository)
class NoteRepositoryImpl implements NoteRepository {
  NoteRepositoryImpl(this._remote, this._local);
}
```

## Offline-First Strategy

1. All writes go to local storage first
2. If online, sync to remote immediately
3. If offline, mark as `isOffline = true`
4. Background sync when connectivity returns
5. Conflict resolution: last-write-wins with timestamp

## Error Handling

Using **Either** type from dartz for functional error handling:

```dart
Future<Either<Failure, Note>> getNoteById(String id) async {
  try {
    final note = await _remote.getNoteById(id);
    return Right(note);
  } on ServerException {
    return Left(ServerFailure());
  }
}
```

## Testing Strategy

### Unit Tests
- Test use cases in isolation
- Mock repositories
- Verify business logic

### Widget Tests
- Test UI components
- Verify user interactions
- Test state changes

### Integration Tests
- Test complete flows
- Test on real devices
- Verify offline/online transitions

## Performance Considerations

1. **Lazy Loading**: Load data on demand
2. **Pagination**: Use Firestore cursors for large collections
3. **Image Caching**: Use cached_network_image
4. **List Optimization**: Use ListView.builder with keys
5. **State Minimization**: Keep state objects immutable
6. **Const Constructors**: Use const where possible
