# Nova Notes Design System

## Philosophy

Nova Notes follows a **Minimal Premium** design philosophy:
- Every pixel serves a purpose
- Content is king
- Motion enhances meaning
- Consistency breeds familiarity
- Performance is a feature

## Color System

### Dark Mode (Primary)

| Token | Hex | Usage |
|-------|-----|-------|
| Background | `#0A0A0F` | App background |
| Surface | `#12121A` | Cards, sheets |
| Surface Elevated | `#1A1A2E` | Elevated cards |
| Surface Glass | `#1E1E32` | Glassmorphism |
| Border | `#2A2A3C` | Dividers, borders |
| Border Subtle | `#1F1F2E` | Subtle separators |
| Text Primary | `#F8FAFC` | Headlines, body |
| Text Secondary | `#94A3B8` | Captions, hints |
| Text Tertiary | `#64748B` | Disabled, metadata |

### Brand Colors

| Token | Hex | Usage |
|-------|-----|-------|
| Electric Blue | `#3B82F6` | Primary actions, links |
| Electric Blue Light | `#60A5FA` | Hover states |
| Deep Purple | `#7C3AED` | Secondary accents |
| Deep Purple Light | `#A78BFA` | Highlights |
| Accent Teal | `#14B8A6` | Success states |
| Accent Rose | `#F43F5E` | Destructive actions |
| Accent Amber | `#F59E0B` | Warnings, pins |
| Accent Emerald | `#10B981` | Completed states |

### Semantic Colors

| Token | Hex | Usage |
|-------|-----|-------|
| Success | `#22C55E` | Success messages |
| Warning | `#F59E0B` | Warning messages |
| Error | `#EF4444` | Error states |
| Info | `#3B82F6` | Info messages |

## Typography

### Font Family
- **Primary**: Inter (Google Fonts)
- **Secondary**: SF Pro (iOS)
- **Arabic**: IBM Plex Sans Arabic

### Type Scale

| Style | Size | Weight | Line Height | Letter Spacing |
|-------|------|--------|-------------|----------------|
| Display Large | 48sp | 700 | 1.1 | -1.5 |
| Display Medium | 36sp | 600 | 1.2 | -1.0 |
| Headline Large | 28sp | 600 | 1.3 | -0.5 |
| Headline Medium | 22sp | 600 | 1.3 | -0.3 |
| Title Large | 18sp | 600 | 1.4 | -0.2 |
| Title Medium | 16sp | 500 | 1.4 | -0.1 |
| Body Large | 16sp | 400 | 1.5 | 0 |
| Body Medium | 14sp | 400 | 1.5 | 0.1 |
| Label Large | 14sp | 500 | 1.4 | 0.1 |
| Label Medium | 12sp | 500 | 1.4 | 0.2 |
| Caption | 11sp | 400 | 1.4 | 0.3 |

## Spacing System

Base unit: **4px**

| Token | Value | Usage |
|-------|-------|-------|
| xs | 4px | Tight spacing |
| sm | 8px | Default padding |
| md | 12px | Component padding |
| lg | 16px | Card padding |
| xl | 24px | Section spacing |
| 2xl | 32px | Large sections |
| 3xl | 48px | Page padding |

## Border Radius

| Token | Value | Usage |
|-------|-------|-------|
| sm | 8px | Chips, badges |
| md | 12px | Buttons, inputs |
| lg | 16px | Cards, sheets |
| xl | 20px | Large cards |
| 2xl | 24px | Modals |
| full | 9999px | Avatars, pills |

## Shadows

### Soft Shadow
```
blur: 16px
offset: 0, 4px
color: black 20% opacity
```

### Elevated Shadow
```
blur: 24px
offset: 0, 8px
color: black 30% opacity
```

### Glow Shadow
```
blur: 20px
spread: 2px
color: electricBlue 30% opacity
```

## Elevation

| Level | Shadow | Usage |
|-------|--------|-------|
| 0 | None | Background |
| 1 | Soft | Cards |
| 2 | Elevated | Modals, FAB |
| 3 | Glow | Primary actions |

## Animation

### Durations
| Token | Value | Usage |
|-------|-------|-------|
| Micro | 100ms | Micro-interactions |
| Fast | 200ms | Hover, tap |
| Normal | 300ms | Transitions |
| Slow | 500ms | Page transitions |

### Curves
| Token | Value | Usage |
|-------|-------|-------|
| Standard | easeInOut | Default transitions |
| Decelerate | easeOut | Entering elements |
| Accelerate | easeIn | Exiting elements |
| Bounce | easeOutBack | Playful interactions |

## Component Specifications

### Cards
- Background: Surface Elevated
- Border: 0.5px Border color
- Border Radius: 16px (lg)
- Padding: 20px
- Shadow: Soft

### Buttons
- Primary: Electric Blue gradient
- Secondary: Surface with border
- Ghost: Transparent with text
- Border Radius: 12px (md)
- Padding: 14px vertical, 24px horizontal

### Inputs
- Background: Surface Elevated
- Border: 1px Border color
- Focus Border: 1.5px Electric Blue
- Border Radius: 12px (md)
- Padding: 14px vertical, 16px horizontal

### Chips
- Background: Surface Glass
- Border: 1px Border color
- Border Radius: 8px (sm)
- Padding: 6px vertical, 12px horizontal
