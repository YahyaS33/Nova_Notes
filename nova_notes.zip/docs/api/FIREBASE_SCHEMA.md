# Firebase Schema

## Collections Structure

```
users/{userId}/
  ├── notes/{noteId}
  ├── tasks/{taskId}
  ├── events/{eventId}
  ├── folders/{folderId}
  ├── tags/{tagId}
  ├── attachments/{attachmentId}
  └── activity/{activityId}
```

## Users Collection

```json
{
  "id": "string",
  "email": "string",
  "displayName": "string",
  "photoUrl": "string",
  "createdAt": "timestamp",
  "lastLoginAt": "timestamp",
  "preferences": {
    "darkMode": "boolean",
    "compactView": "boolean",
    "notificationsEnabled": "boolean",
    "aiSuggestionsEnabled": "boolean",
    "defaultView": "string",
    "language": "string"
  },
  "subscription": {
    "tier": "string (free|pro|team|enterprise)",
    "expiresAt": "timestamp",
    "isActive": "boolean"
  }
}
```

## Notes Collection

```json
{
  "id": "string",
  "title": "string",
  "content": "string (rich text / markdown)",
  "plainText": "string",
  "createdAt": "timestamp",
  "updatedAt": "timestamp",
  "isPinned": "boolean",
  "isArchived": "boolean",
  "folderId": "string (nullable)",
  "tags": ["string"],
  "attachments": ["string (URLs)"],
  "aiSummary": "string (nullable)",
  "extractedTasks": ["string"],
  "color": "string (nullable)",
  "isOffline": "boolean",
  "reminderDate": "timestamp (nullable)"
}
```

## Tasks Collection

```json
{
  "id": "string",
  "title": "string",
  "description": "string (nullable)",
  "priority": "string (none|low|medium|high|urgent)",
  "status": "string (todo|inProgress|completed|archived)",
  "dueDate": "timestamp (nullable)",
  "reminderDate": "timestamp (nullable)",
  "createdAt": "timestamp",
  "updatedAt": "timestamp",
  "projectId": "string (nullable)",
  "tags": ["string"],
  "subtasks": ["string"],
  "isRecurring": "boolean",
  "recurrenceRule": {
    "type": "string (daily|weekly|monthly|yearly)",
    "interval": "number",
    "endDate": "timestamp (nullable)",
    "daysOfWeek": ["number"]
  },
  "estimatedMinutes": "number (nullable)",
  "actualMinutes": "number (nullable)",
  "color": "string (nullable)",
  "noteId": "string (nullable)",
  "isOffline": "boolean"
}
```

## Events Collection

```json
{
  "id": "string",
  "title": "string",
  "description": "string (nullable)",
  "startTime": "timestamp",
  "endTime": "timestamp",
  "isAllDay": "boolean",
  "location": "string (nullable)",
  "type": "string (personal|work|meeting|reminder|focus|birthday|holiday|custom)",
  "color": "string (nullable)",
  "attendees": ["string"],
  "recurrenceRule": "string (nullable)",
  "reminderMinutes": "string (nullable)",
  "isRecurring": "boolean",
  "noteId": "string (nullable)",
  "taskId": "string (nullable)",
  "isOffline": "boolean"
}
```

## Folders Collection

```json
{
  "id": "string",
  "name": "string",
  "parentId": "string (nullable)",
  "color": "string (nullable)",
  "createdAt": "timestamp",
  "noteCount": "number"
}
```

## Tags Collection

```json
{
  "id": "string",
  "name": "string",
  "color": "string (nullable)",
  "usageCount": "number"
}
```

## Security Rules

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // Helper functions
    function isAuthenticated() {
      return request.auth != null;
    }

    function isOwner(userId) {
      return request.auth.uid == userId;
    }

    function isValidNote() {
      return request.resource.data.title is string
        && request.resource.data.title.size() > 0
        && request.resource.data.title.size() <= 500
        && request.resource.data.createdAt is timestamp;
    }

    // Users collection
    match /users/{userId} {
      allow read: if isAuthenticated() && isOwner(userId);
      allow write: if isAuthenticated() && isOwner(userId);

      // Subcollections
      match /notes/{noteId} {
        allow read: if isAuthenticated() && isOwner(userId);
        allow create: if isAuthenticated() && isOwner(userId) && isValidNote();
        allow update: if isAuthenticated() && isOwner(userId) && isValidNote();
        allow delete: if isAuthenticated() && isOwner(userId);
      }

      match /tasks/{taskId} {
        allow read, write: if isAuthenticated() && isOwner(userId);
      }

      match /events/{eventId} {
        allow read, write: if isAuthenticated() && isOwner(userId);
      }

      match /folders/{folderId} {
        allow read, write: if isAuthenticated() && isOwner(userId);
      }

      match /tags/{tagId} {
        allow read, write: if isAuthenticated() && isOwner(userId);
      }
    }
  }
}
```

## Indexes

### Composite Indexes

```json
{
  "collectionGroup": "notes",
  "queryScope": "COLLECTION",
  "fields": [
    { "fieldPath": "userId", "order": "ASCENDING" },
    { "fieldPath": "isPinned", "order": "DESCENDING" },
    { "fieldPath": "updatedAt", "order": "DESCENDING" }
  ]
}
```

### Single Field Indexes
- `notes.updatedAt` (DESC)
- `notes.isPinned` (ASC)
- `tasks.dueDate` (ASC)
- `tasks.priority` (ASC)
- `events.startTime` (ASC)
