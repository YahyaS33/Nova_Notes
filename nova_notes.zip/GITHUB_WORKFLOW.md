# Nova Notes - Complete GitHub Workflow

## Initial Setup (One-time)

### 1. Create GitHub Repository

```bash
# Create repository on GitHub (via web UI or gh CLI)
gh repo create nova-notes --public --description "Premium All-in-One Productivity Ecosystem"

# Or create manually at https://github.com/new
```

### 2. Initialize Local Repository

```bash
# Navigate to project
cd nova-notes

# Initialize Git
git init

# Add all files
git add .

# Create initial commit
git commit -m "feat: initial project setup

- Complete Clean Architecture implementation
- Smart Notes, Calendar, Tasks, AI Assistant features
- Firebase integration (Auth, Firestore, Messaging)
- Premium dark-first design system
- Offline-first architecture
- BLoC state management
- Production-ready CI/CD pipeline"

# Connect to remote
git remote add origin https://github.com/your-org/nova-notes.git

# Push to main
git branch -M main
git push -u origin main
```

## Daily Development Workflow

### Feature Development

```bash
# Pull latest changes
git pull origin main

# Create feature branch
git checkout -b feature/smart-search

# Make changes, then stage
git add lib/features/search/

# Commit with conventional format
git commit -m "feat(search): implement full-text search with debouncing

- Add SearchBloc with debounced queries
- Integrate with NoteRepository search
- Add search UI with recent queries
- Optimize with isolate-based indexing"

# Push feature branch
git push origin feature/smart-search

# Create Pull Request (via GitHub UI or gh CLI)
gh pr create --title "feat(search): implement full-text search" --body "Implements #42"
```

### Code Review Process

```bash
# Reviewer: checkout PR branch
git fetch origin pull/123/head:pr-123
git checkout pr-123

# Run tests
flutter test

# Run analysis
flutter analyze

# Check formatting
dart format --set-exit-if-changed .

# Approve and merge (maintainer)
gh pr review 123 --approve
gh pr merge 123 --squash --delete-branch
```

## Release Workflow

### Version Bump

```bash
# Update version in pubspec.yaml
# Example: 1.0.0+1 -> 1.1.0+2

# Update CHANGELOG.md

# Commit version bump
git add pubspec.yaml CHANGELOG.md
git commit -m "chore(release): bump version to 1.1.0"

# Create release branch
git checkout -b release/v1.1.0

# Push release branch
git push origin release/v1.1.0
```

### Tag Release

```bash
# Merge release to main
git checkout main
git merge release/v1.1.0

# Create annotated tag
git tag -a v1.1.0 -m "Release v1.1.0

Features:
- Google Calendar sync
- Biometric authentication
- Widget support

Fixes:
- Offline sync edge cases
- Calendar timezone issues"

# Push tag (triggers release workflow)
git push origin main --tags
```

## Branch Strategy

```
main          ← Production-ready, protected
  │
  ├── develop ← Integration branch
  │     │
  │     ├── feature/notes-markdown
  │     ├── feature/ai-summaries
  │     └── fix/calendar-timezone
  │
  ├── release/v1.1.0
  │
  └── hotfix/v1.0.1
```

## Useful Commands

```bash
# View commit history (pretty)
git log --oneline --graph --decorate --all

# Interactive rebase (clean up commits)
git rebase -i HEAD~5

# Stash changes temporarily
git stash push -m "WIP: search implementation"
git stash pop

# View diff before commit
git diff --cached

# Undo last commit (keep changes)
git reset --soft HEAD~1

# Force push (use carefully)
git push origin feature/branch --force-with-lease

# Clean untracked files
git clean -fd

# View blame for file
git blame lib/main.dart

# Search commit history
git log --all --grep="feat(search)"
```

## CI/CD Pipeline

### Automated Checks on PR
1. Code analysis (`flutter analyze`)
2. Formatting check (`dart format`)
3. Unit tests (`flutter test`)
4. Widget tests
5. Build verification (Android + iOS)

### Release Pipeline
1. Tag push triggers workflow
2. Build release APK + AAB
3. Build release IPA
4. Upload to GitHub Releases
5. Deploy to Play Store (Internal)
6. Deploy to TestFlight

## Environment Secrets

Configure in GitHub Settings > Secrets and variables > Actions:

```
KEYSTORE_BASE64          # Android signing keystore (base64)
KEYSTORE_PASSWORD        # Keystore password
KEY_PASSWORD             # Key password
KEY_ALIAS                # Key alias
IOS_P12_BASE64           # iOS distribution certificate
IOS_P12_PASSWORD         # Certificate password
APPSTORE_ISSUER_ID       # App Store Connect issuer ID
APPSTORE_API_KEY_ID      # App Store Connect API key ID
APPSTORE_API_PRIVATE_KEY # App Store Connect private key
FIREBASE_TOKEN           # Firebase CLI token
```
