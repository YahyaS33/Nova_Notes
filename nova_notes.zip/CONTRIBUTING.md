# Contributing to Nova Notes

Thank you for your interest in contributing to Nova Notes! This document provides guidelines and standards for contributing to the project.

## Code of Conduct

- Be respectful and inclusive
- Provide constructive feedback
- Focus on what is best for the community and users
- Show empathy towards others

## Development Setup

### Prerequisites

- Flutter SDK >= 3.16.0
- Dart SDK >= 3.2.0
- Git
- Firebase CLI (for backend features)

### Setup Steps

1. Fork the repository
2. Clone your fork: `git clone https://github.com/your-username/nova-notes.git`
3. Install dependencies: `flutter pub get`
4. Generate code: `flutter pub run build_runner build`
5. Run the app: `flutter run`

## Branch Naming Convention

```
feature/short-description    # New features
fix/short-description        # Bug fixes
docs/short-description       # Documentation updates
refactor/short-description   # Code refactoring
test/short-description       # Test additions/updates
chore/short-description      # Maintenance tasks
```

## Commit Message Convention

We follow the [Conventional Commits](https://www.conventionalcommits.org/) specification:

```
<type>(<scope>): <description>

[optional body]

[optional footer]
```

### Types

- `feat`: New feature
- `fix`: Bug fix
- `docs`: Documentation changes
- `style`: Code style changes (formatting, semicolons, etc.)
- `refactor`: Code refactoring
- `perf`: Performance improvements
- `test`: Adding or updating tests
- `chore`: Build process or auxiliary tool changes

### Examples

```
feat(notes): add markdown support to editor
fix(calendar): resolve timezone issue in event creation
docs(readme): update installation instructions
refactor(auth): simplify login flow
```

## Pull Request Process

1. Update your fork to the latest `main` branch
2. Create a feature branch from `main`
3. Make your changes following our coding standards
4. Add or update tests as needed
5. Update documentation if required
6. Ensure all tests pass: `flutter test`
7. Ensure code analysis passes: `flutter analyze`
8. Submit a pull request with a clear description

### PR Template

```markdown
## Description
Brief description of the changes

## Type of Change
- [ ] Bug fix
- [ ] New feature
- [ ] Breaking change
- [ ] Documentation update

## Testing
Describe the tests you ran

## Screenshots (if applicable)
Add screenshots for UI changes

## Checklist
- [ ] Code follows style guidelines
- [ ] Tests added/updated
- [ ] Documentation updated
- [ ] No breaking changes (or documented)
```

## Coding Standards

### Dart/Flutter Style

- Follow the [Effective Dart](https://dart.dev/guides/language/effective-dart) guidelines
- Use `flutter_lints` for static analysis
- Maximum line length: 100 characters
- Use trailing commas for better diffs
- Prefer `const` constructors where possible

### Architecture Rules

- Follow Clean Architecture principles
- Keep business logic in the domain layer
- UI should only depend on presentation layer
- Use dependency injection for all dependencies
- Write unit tests for use cases and repositories

### State Management

- Use BLoC pattern for complex state
- Keep UI reactive with BlocBuilder/BlocListener
- Avoid business logic in widgets
- Use Equatable for state classes

### Performance

- Use `const` widgets where possible
- Implement lazy loading for lists
- Cache network images
- Minimize rebuilds with proper `key` usage
- Profile before optimizing

## Testing Requirements

### Unit Tests

- Test all use cases
- Test repository methods
- Mock external dependencies
- Aim for >80% code coverage

### Widget Tests

- Test critical UI flows
- Test user interactions
- Verify state changes

### Integration Tests

- Test end-to-end flows
- Test on multiple screen sizes
- Test offline scenarios

## Documentation

- Update README for user-facing changes
- Update architecture docs for structural changes
- Add inline documentation for complex logic
- Update CHANGELOG.md

## Release Process

1. Update version in `pubspec.yaml`
2. Update `CHANGELOG.md`
3. Create release branch: `release/vX.Y.Z`
4. Run full test suite
5. Create PR to `main`
6. After merge, tag release: `git tag vX.Y.Z`
7. Push tag: `git push origin vX.Y.Z`

## Questions?

- Open an issue for questions
- Join our community discussions
- Contact maintainers at support@novanotes.app

---

Thank you for contributing to Nova Notes!
