import 'package:flutter_test/flutter_test.dart';
import 'package:nova_notes/features/tasks/domain/entities/task.dart';

void main() {
  group('Task Entity', () {
    test('should create a valid Task', () {
      final task = Task(
        id: '1',
        title: 'Test Task',
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
      );
      expect(task.id, '1');
      expect(task.title, 'Test Task');
      expect(task.priority, TaskPriority.medium);
      expect(task.status, TaskStatus.todo);
    });

    test('should detect overdue tasks', () {
      final task = Task(
        id: '1',
        title: 'Overdue',
        dueDate: DateTime.now().subtract(const Duration(days: 1)),
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
      );
      expect(task.isOverdue, true);
    });
  });
}
