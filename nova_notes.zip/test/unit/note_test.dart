import 'package:flutter_test/flutter_test.dart';
import 'package:nova_notes/features/notes/domain/entities/note.dart';

void main() {
  group('Note Entity', () {
    test('should create a valid Note', () {
      final note = Note(
        id: '1',
        title: 'Test Note',
        content: 'Test content',
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
      );
      expect(note.id, '1');
      expect(note.title, 'Test Note');
      expect(note.isPinned, false);
      expect(note.isArchived, false);
    });

    test('should copy with new values', () {
      final note = Note(
        id: '1',
        title: 'Test',
        content: 'Content',
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
      );
      final updated = note.copyWith(title: 'Updated');
      expect(updated.title, 'Updated');
      expect(updated.id, note.id);
    });
  });
}
