import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:nova_notes/features/notes/presentation/bloc/notes_bloc.dart';
import 'package:nova_notes/features/tasks/presentation/bloc/tasks_bloc.dart';
import 'package:nova_notes/features/calendar/presentation/bloc/calendar_bloc.dart';
import 'package:nova_notes/features/dashboard/presentation/pages/dashboard_page.dart';

void main() {
  group('DashboardPage', () {
    testWidgets('should render dashboard', (WidgetTester tester) async {
      await tester.pumpWidget(
        MaterialApp(
          home: MultiBlocProvider(
            providers: [
              BlocProvider(create: (_) => NotesBloc()),
              BlocProvider(create: (_) => TasksBloc()),
              BlocProvider(create: (_) => CalendarBloc()),
            ],
            child: const DashboardPage(),
          ),
        ),
      );

      expect(find.text('Notes'), findsOneWidget);
      expect(find.text('Tasks'), findsOneWidget);
      expect(find.text('Calendar'), findsOneWidget);
    });
  });
}
