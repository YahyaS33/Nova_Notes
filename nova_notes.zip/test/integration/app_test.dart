import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';
import 'package:nova_notes/main.dart' as app;

void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();

  group('App Integration Test', () {
    testWidgets('should launch app and navigate', (WidgetTester tester) async {
      app.main();
      await tester.pumpAndSettle();

      // Wait for splash screen
      await Future.delayed(const Duration(seconds: 4));
      await tester.pumpAndSettle();

      // Verify dashboard is shown
      expect(find.text('Home'), findsOneWidget);
    });
  });
}
