#include "my_application.h"
#include <flutter_linux/flutter_linux.h>

int main(int argc, char** argv) {
  g_autoptr(MyApplication) app = my_application_new("com.novanotes.app", G_APPLICATION_FLAGS_NONE);
  return g_application_run(G_APPLICATION(app), argc, argv);
}
