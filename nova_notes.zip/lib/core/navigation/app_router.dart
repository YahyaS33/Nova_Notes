import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../constants/app_constants.dart';
import '../../features/dashboard/presentation/pages/dashboard_page.dart';
import '../../features/notes/presentation/pages/notes_page.dart';
import '../../features/notes/presentation/pages/note_editor_page.dart';
import '../../features/calendar/presentation/pages/calendar_page.dart';
import '../../features/tasks/presentation/pages/tasks_page.dart';
import '../../features/ai/presentation/pages/ai_assistant_page.dart';
import '../../features/auth/presentation/pages/login_page.dart';
import '../../features/auth/presentation/pages/register_page.dart';
import '../../features/dashboard/presentation/pages/splash_page.dart';
import '../../features/dashboard/presentation/pages/onboarding_page.dart';
import '../../features/dashboard/presentation/pages/search_page.dart';
import '../../features/dashboard/presentation/pages/focus_page.dart';

/// Centralized router configuration using GoRouter
class AppRouter {
  AppRouter._();

  static final _rootNavigatorKey = GlobalKey<NavigatorState>();
  static final _shellNavigatorKey = GlobalKey<NavigatorState>();

  static GoRouter get router => GoRouter(
    navigatorKey: _rootNavigatorKey,
    initialLocation: AppConstants.routeSplash,
    debugLogDiagnostics: true,

    routes: [
      // Splash
      GoRoute(
        path: AppConstants.routeSplash,
        builder: (context, state) => const SplashPage(),
      ),

      // Onboarding
      GoRoute(
        path: AppConstants.routeOnboarding,
        builder: (context, state) => const OnboardingPage(),
      ),

      // Auth
      GoRoute(
        path: AppConstants.routeLogin,
        builder: (context, state) => const LoginPage(),
      ),
      GoRoute(
        path: AppConstants.routeRegister,
        builder: (context, state) => const RegisterPage(),
      ),

      // Main App Shell with Bottom Navigation
      ShellRoute(
        navigatorKey: _shellNavigatorKey,
        builder: (context, state, child) => ScaffoldWithNavBar(child: child),
        routes: [
          GoRoute(
            path: AppConstants.routeDashboard,
            builder: (context, state) => const DashboardPage(),
          ),
          GoRoute(
            path: AppConstants.routeNotes,
            builder: (context, state) => const NotesPage(),
          ),
          GoRoute(
            path: AppConstants.routeCalendar,
            builder: (context, state) => const CalendarPage(),
          ),
          GoRoute(
            path: AppConstants.routeTasks,
            builder: (context, state) => const TasksPage(),
          ),
        ],
      ),

      // Detail & Editor Pages (full screen)
      GoRoute(
        path: AppConstants.routeNoteEditor,
        builder: (context, state) {
          final noteId = state.uri.queryParameters['id'];
          return NoteEditorPage(noteId: noteId);
        },
      ),

      GoRoute(
        path: AppConstants.routeAIAssistant,
        builder: (context, state) => const AIAssistantPage(),
      ),

      GoRoute(
        path: AppConstants.routeSearch,
        builder: (context, state) => const SearchPage(),
      ),

      GoRoute(
        path: AppConstants.routeFocus,
        builder: (context, state) => const FocusPage(),
      ),
    ],

    errorBuilder: (context, state) => Scaffold(
      body: Center(
        child: Text(
          'Page not found: ${state.uri.path}',
          style: Theme.of(context).textTheme.headlineMedium,
        ),
      ),
    ),
  );
}

/// Scaffold with persistent bottom navigation
class ScaffoldWithNavBar extends StatelessWidget {
  final Widget child;

  const ScaffoldWithNavBar({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    final location = GoRouterState.of(context).uri.path;

    return Scaffold(
      body: child,
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.surface.withOpacity(0.9),
          border: Border(
            top: BorderSide(
              color: Theme.of(context).dividerColor.withOpacity(0.3),
              width: 0.5,
            ),
          ),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _NavItem(
                  icon: Icons.dashboard_rounded,
                  label: 'Home',
                  isActive: location == AppConstants.routeDashboard,
                  onTap: () => context.go(AppConstants.routeDashboard),
                ),
                _NavItem(
                  icon: Icons.edit_note_rounded,
                  label: 'Notes',
                  isActive: location == AppConstants.routeNotes,
                  onTap: () => context.go(AppConstants.routeNotes),
                ),
                _NavItem(
                  icon: Icons.calendar_month_rounded,
                  label: 'Calendar',
                  isActive: location == AppConstants.routeCalendar,
                  onTap: () => context.go(AppConstants.routeCalendar),
                ),
                _NavItem(
                  icon: Icons.task_alt_rounded,
                  label: 'Tasks',
                  isActive: location == AppConstants.routeTasks,
                  onTap: () => context.go(AppConstants.routeTasks),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _NavItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool isActive;
  final VoidCallback onTap;

  const _NavItem({
    required this.icon,
    required this.label,
    required this.isActive,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final color = isActive
        ? Theme.of(context).colorScheme.primary
        : Theme.of(context).textTheme.labelMedium?.color;

    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: isActive
              ? Theme.of(context).colorScheme.primary.withOpacity(0.1)
              : Colors.transparent,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, color: color, size: 24),
            const SizedBox(height: 2),
            Text(
              label,
              style: Theme.of(context).textTheme.labelSmall?.copyWith(
                color: color,
                fontWeight: isActive ? FontWeight.w600 : FontWeight.w400,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
