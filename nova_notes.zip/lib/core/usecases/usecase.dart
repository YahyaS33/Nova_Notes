import 'package:dartz/dartz.dart';
import '../errors/failures.dart';

/// Base UseCase class implementing Clean Architecture pattern
/// All domain use cases extend this class
abstract class UseCase<Type, Params> {
  Future<Either<Failure, Type>> call(Params params);
}

/// UseCase with no parameters
abstract class NoParamsUseCase<Type> {
  Future<Either<Failure, Type>> call();
}

/// Stream-based UseCase for real-time data
abstract class StreamUseCase<Type, Params> {
  Stream<Either<Failure, Type>> call(Params params);
}

/// No parameters class
class NoParams {
  const NoParams();
}
