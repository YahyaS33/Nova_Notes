/// Nova Notes - Application Constants
/// Centralized configuration for the entire app
class AppConstants {
  AppConstants._();

  // ─── App Info ───────────────────────────────────────────
  static const String appName = 'Nova Notes';
  static const String appTagline = 'Think. Plan. Create.';
  static const String appVersion = '1.0.0';
  static const String appBuild = '1';
  static const String supportEmail = 'support@novanotes.app';
  static const String privacyPolicyUrl = 'https://novanotes.app/privacy';
  static const String termsUrl = 'https://novanotes.app/terms';

  // ─── Feature Flags ──────────────────────────────────────
  static const bool enableAI = true;
  static const bool enableOfflineSync = true;
  static const bool enablePushNotifications = true;
  static const bool enableAnalytics = true;
  static const bool enableBiometricAuth = false; // Future
  static const bool enableGoogleCalendarSync = false; // Future
  static const bool enableAppleCalendarSync = false; // Future

  // ─── Limits ─────────────────────────────────────────────
  static const int maxNotesFree = 50;
  static const int maxTasksFree = 30;
  static const int maxFileSizeMB = 25;
  static const int maxAttachmentsPerNote = 10;
  static const int searchDebounceMs = 300;
  static const int autoSaveDebounceMs = 2000;
  static const int syncIntervalMinutes = 5;

  // ─── AI Config ──────────────────────────────────────────
  static const int aiSummaryMaxLength = 300;
  static const int aiMaxTokens = 1024;
  static const double aiTemperature = 0.7;

  // ─── Animation Durations ────────────────────────────────
  static const Duration microDuration = Duration(milliseconds: 100);
  static const Duration fastDuration = Duration(milliseconds: 200);
  static const Duration normalDuration = Duration(milliseconds: 300);
  static const Duration slowDuration = Duration(milliseconds: 500);
  static const Duration pageTransitionDuration = Duration(milliseconds: 400);

  // ─── Storage Keys ───────────────────────────────────────
  static const String keyThemeMode = 'theme_mode';
  static const String keyUserPrefs = 'user_preferences';
  static const String keyLastSync = 'last_sync_timestamp';
  static const String keyOnboardingComplete = 'onboarding_complete';
  static const String keyAuthToken = 'auth_token';

  // ─── Routes ─────────────────────────────────────────────
  static const String routeSplash = '/';
  static const String routeOnboarding = '/onboarding';
  static const String routeLogin = '/login';
  static const String routeRegister = '/register';
  static const String routeDashboard = '/dashboard';
  static const String routeNotes = '/notes';
  static const String routeNoteDetail = '/notes/:id';
  static const String routeNoteEditor = '/notes/editor';
  static const String routeCalendar = '/calendar';
  static const String routeTasks = '/tasks';
  static const String routeTaskDetail = '/tasks/:id';
  static const String routeAIAssistant = '/ai';
  static const String routeSettings = '/settings';
  static const String routeProfile = '/profile';
  static const String routeSearch = '/search';
  static const String routeFocus = '/focus';

  // ─── Collections ────────────────────────────────────────
  static const String collectionUsers = 'users';
  static const String collectionNotes = 'notes';
  static const String collectionTasks = 'tasks';
  static const String collectionEvents = 'events';
  static const String collectionFolders = 'folders';
  static const String collectionTags = 'tags';
  static const String collectionAttachments = 'attachments';
  static const String collectionActivity = 'activity';

  // ─── Priority Colors ──────────────────────────────────
  static const Map<String, int> priorityColors = {
    'urgent': 0xFFEF4444,
    'high': 0xFFF59E0B,
    'medium': 0xFF3B82F6,
    'low': 0xFF10B981,
    'none': 0xFF64748B,
  };
}
