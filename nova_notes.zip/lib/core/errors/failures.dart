import 'package:equatable/equatable.dart';

/// Base Failure class for the app
abstract class Failure extends Equatable {
  final String message;
  final String? code;

  const Failure({required this.message, this.code});

  @override
  List<Object?> get props => [message, code];
}

class ServerFailure extends Failure {
  const ServerFailure({String message = 'Server error occurred', String? code})
      : super(message: message, code: code);
}

class CacheFailure extends Failure {
  const CacheFailure({String message = 'Cache error occurred', String? code})
      : super(message: message, code: code);
}

class NetworkFailure extends Failure {
  const NetworkFailure({String message = 'No internet connection', String? code})
      : super(message: message, code: code);
}

class AuthFailure extends Failure {
  const AuthFailure({String message = 'Authentication failed', String? code})
      : super(message: message, code: code);
}

class ValidationFailure extends Failure {
  final Map<String, String>? errors;

  const ValidationFailure({
    String message = 'Validation failed',
    this.errors,
    String? code,
  }) : super(message: message, code: code);

  @override
  List<Object?> get props => [message, code, errors];
}

class NotFoundFailure extends Failure {
  const NotFoundFailure({String message = 'Resource not found', String? code})
      : super(message: message, code: code);
}

class PermissionFailure extends Failure {
  const PermissionFailure({String message = 'Permission denied', String? code})
      : super(message: message, code: code);
}
