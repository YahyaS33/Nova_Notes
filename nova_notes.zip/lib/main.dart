import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:firebase_core/firebase_core.dart';
import 'core/theme/app_theme.dart';
import 'core/navigation/app_router.dart';
import 'core/services/connectivity_service.dart';
import 'core/services/notification_service.dart';
import 'features/notes/presentation/bloc/notes_bloc.dart';
import 'features/tasks/presentation/bloc/tasks_bloc.dart';
import 'features/calendar/presentation/bloc/calendar_bloc.dart';

/// Nova Notes - Premium All-in-One Productivity Ecosystem
/// 
/// Architecture: Clean Architecture + BLoC Pattern
/// State Management: flutter_bloc
/// Navigation: go_router
/// Backend: Firebase (Auth, Firestore, Messaging)
/// Local Storage: Hive + SQLite
/// AI: Google Generative AI
void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Initialize Firebase
  await Firebase.initializeApp();

  // Initialize services
  final connectivityService = ConnectivityService();
  connectivityService.initialize();

  final notificationService = NotificationService();
  await notificationService.initialize();

  // Set preferred orientations
  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);

  // Set system UI overlay style
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
      systemNavigationBarColor: Colors.transparent,
      systemNavigationBarIconBrightness: Brightness.light,
    ),
  );

  runApp(const NovaNotesApp());
}

class NovaNotesApp extends StatelessWidget {
  const NovaNotesApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ScreenUtilInit(
      designSize: const Size(375, 812),
      minTextAdapt: true,
      splitScreenMode: true,
      builder: (context, child) {
        return MultiBlocProvider(
          providers: [
            BlocProvider(create: (_) => NotesBloc(repository: throw UnimplementedError())),
            BlocProvider(create: (_) => TasksBloc()),
            BlocProvider(create: (_) => CalendarBloc()),
          ],
          child: MaterialApp.router(
            title: 'Nova Notes',
            debugShowCheckedModeBanner: false,
            theme: AppTheme.darkTheme,
            darkTheme: AppTheme.darkTheme,
            themeMode: ThemeMode.dark,
            routerConfig: AppRouter.router,
            builder: (context, child) {
              return ScrollConfiguration(
                behavior: const ScrollBehavior().copyWith(
                  physics: const BouncingScrollPhysics(),
                ),
                child: child!,
              );
            },
          ),
        );
      },
    );
  }
}
