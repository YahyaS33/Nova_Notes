import 'package:dartz/dartz.dart';
import '../../../../core/errors/failures.dart';
import '../entities/note.dart';

/// Note Repository Contract - Clean Architecture
abstract class NoteRepository {
  /// Get all notes with optional filters
  Future<Either<Failure, List<Note>>> getNotes({
    String? folderId,
    List<String>? tags,
    bool? isPinned,
    bool? isArchived,
    String? searchQuery,
  });

  /// Get single note by ID
  Future<Either<Failure, Note>> getNoteById(String id);

  /// Create new note
  Future<Either<Failure, Note>> createNote(Note note);

  /// Update existing note
  Future<Either<Failure, Note>> updateNote(Note note);

  /// Delete note
  Future<Either<Failure, Unit>> deleteNote(String id);

  /// Toggle pin status
  Future<Either<Failure, Note>> togglePin(String id);

  /// Toggle archive status
  Future<Either<Failure, Note>> toggleArchive(String id);

  /// Get pinned notes
  Future<Either<Failure, List<Note>>> getPinnedNotes();

  /// Get recent notes
  Future<Either<Failure, List<Note>>> getRecentNotes({int limit = 5});

  /// Search notes
  Future<Either<Failure, List<Note>>> searchNotes(String query);

  /// Stream of notes for real-time updates
  Stream<Either<Failure, List<Note>>> watchNotes();

  /// Sync offline notes
  Future<Either<Failure, Unit>> syncOfflineNotes();

  /// Get folders
  Future<Either<Failure, List<Folder>>> getFolders();

  /// Create folder
  Future<Either<Failure, Folder>> createFolder(Folder folder);

  /// Get tags
  Future<Either<Failure, List<Tag>>> getTags();

  /// Generate AI summary
  Future<Either<Failure, String>> generateSummary(String noteId);

  /// Extract tasks from note
  Future<Either<Failure, List<String>>> extractTasks(String noteId);
}
