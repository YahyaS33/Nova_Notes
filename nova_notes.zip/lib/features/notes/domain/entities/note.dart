import 'package:equatable/equatable.dart';

/// Note Entity - Core business object
class Note extends Equatable {
  final String id;
  final String title;
  final String content;
  final String? plainText;
  final DateTime createdAt;
  final DateTime updatedAt;
  final bool isPinned;
  final bool isArchived;
  final String? folderId;
  final List<String> tags;
  final List<String> attachments;
  final String? aiSummary;
  final List<String> extractedTasks;
  final String? color;
  final bool isOffline;
  final DateTime? reminderDate;

  const Note({
    required this.id,
    required this.title,
    required this.content,
    this.plainText,
    required this.createdAt,
    required this.updatedAt,
    this.isPinned = false,
    this.isArchived = false,
    this.folderId,
    this.tags = const [],
    this.attachments = const [],
    this.aiSummary,
    this.extractedTasks = const [],
    this.color,
    this.isOffline = false,
    this.reminderDate,
  });

  Note copyWith({
    String? id,
    String? title,
    String? content,
    String? plainText,
    DateTime? createdAt,
    DateTime? updatedAt,
    bool? isPinned,
    bool? isArchived,
    String? folderId,
    List<String>? tags,
    List<String>? attachments,
    String? aiSummary,
    List<String>? extractedTasks,
    String? color,
    bool? isOffline,
    DateTime? reminderDate,
  }) {
    return Note(
      id: id ?? this.id,
      title: title ?? this.title,
      content: content ?? this.content,
      plainText: plainText ?? this.plainText,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      isPinned: isPinned ?? this.isPinned,
      isArchived: isArchived ?? this.isArchived,
      folderId: folderId ?? this.folderId,
      tags: tags ?? this.tags,
      attachments: attachments ?? this.attachments,
      aiSummary: aiSummary ?? this.aiSummary,
      extractedTasks: extractedTasks ?? this.extractedTasks,
      color: color ?? this.color,
      isOffline: isOffline ?? this.isOffline,
      reminderDate: reminderDate ?? this.reminderDate,
    );
  }

  @override
  List<Object?> get props => [
    id, title, content, plainText, createdAt, updatedAt,
    isPinned, isArchived, folderId, tags, attachments,
    aiSummary, extractedTasks, color, isOffline, reminderDate,
  ];
}

/// Folder Entity
class Folder extends Equatable {
  final String id;
  final String name;
  final String? parentId;
  final String? color;
  final DateTime createdAt;
  final int noteCount;

  const Folder({
    required this.id,
    required this.name,
    this.parentId,
    this.color,
    required this.createdAt,
    this.noteCount = 0,
  });

  @override
  List<Object?> get props => [id, name, parentId, color, createdAt, noteCount];
}

/// Tag Entity
class Tag extends Equatable {
  final String id;
  final String name;
  final String? color;
  final int usageCount;

  const Tag({
    required this.id,
    required this.name,
    this.color,
    this.usageCount = 0,
  });

  @override
  List<Object?> get props => [id, name, color, usageCount];
}
