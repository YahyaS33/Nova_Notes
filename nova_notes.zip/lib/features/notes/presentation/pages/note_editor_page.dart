import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:uuid/uuid.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/utils/extensions.dart';
import '../../domain/entities/note.dart';
import '../bloc/notes_bloc.dart';

class NoteEditorPage extends StatefulWidget {
  final String? noteId;

  const NoteEditorPage({super.key, this.noteId});

  @override
  State<NoteEditorPage> createState() => _NoteEditorPageState();
}

class _NoteEditorPageState extends State<NoteEditorPage> {
  final _titleController = TextEditingController();
  final _contentController = TextEditingController();
  bool _isPinned = false;
  List<String> _tags = [];
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    if (widget.noteId != null) {
      // TODO: Load existing note
    }
  }

  @override
  void dispose() {
    _titleController.dispose();
    _contentController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: context.theme.scaffoldBackgroundColor,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded),
          onPressed: () => context.pop(),
        ),
        actions: [
          IconButton(
            icon: Icon(
              _isPinned ? Icons.push_pin_rounded : Icons.push_pin_outlined,
              color: _isPinned ? AppTheme.accentAmber : null,
            ),
            onPressed: () => setState(() => _isPinned = !_isPinned),
          ),
          IconButton(
            icon: const Icon(Icons.more_vert_rounded),
            onPressed: () => _showOptions(context),
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 24),
              physics: const BouncingScrollPhysics(),
              child: Column(
                children: [
                  TextField(
                    controller: _titleController,
                    style: context.textTheme.headlineMedium?.copyWith(
                      fontWeight: FontWeight.w700,
                    ),
                    decoration: InputDecoration(
                      hintText: 'Note title',
                      hintStyle: context.textTheme.headlineMedium?.copyWith(
                        color: AppTheme.textTertiaryDark,
                      ),
                      border: InputBorder.none,
                      contentPadding: EdgeInsets.zero,
                    ),
                  ),
                  const SizedBox(height: 16),
                  TextField(
                    controller: _contentController,
                    style: context.textTheme.bodyLarge,
                    maxLines: null,
                    minLines: 10,
                    decoration: InputDecoration(
                      hintText: 'Start writing...',
                      hintStyle: context.textTheme.bodyLarge?.copyWith(
                        color: AppTheme.textTertiaryDark,
                      ),
                      border: InputBorder.none,
                      contentPadding: EdgeInsets.zero,
                    ),
                  ),
                ],
              ),
            ),
          ),
          // Bottom toolbar
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppTheme.darkSurfaceElevated,
              border: Border(
                top: BorderSide(color: AppTheme.darkBorder.withOpacity(0.5)),
              ),
            ),
            child: SafeArea(
              child: Row(
                children: [
                  _ToolbarButton(
                    icon: Icons.format_bold_rounded,
                    onTap: () {},
                  ),
                  _ToolbarButton(
                    icon: Icons.format_italic_rounded,
                    onTap: () {},
                  ),
                  _ToolbarButton(
                    icon: Icons.format_list_bulleted_rounded,
                    onTap: () {},
                  ),
                  _ToolbarButton(
                    icon: Icons.attach_file_rounded,
                    onTap: () {},
                  ),
                  const Spacer(),
                  _ToolbarButton(
                    icon: Icons.auto_awesome_rounded,
                    color: AppTheme.deepPurple,
                    onTap: () {},
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _saveNote,
        icon: const Icon(Icons.save_rounded),
        label: const Text('Save'),
      ).animate().scale(delay: 300.ms, duration: 300.ms),
    );
  }

  void _saveNote() {
    if (_titleController.text.isEmpty) return;

    final note = Note(
      id: widget.noteId ?? const Uuid().v4(),
      title: _titleController.text,
      content: _contentController.text,
      plainText: _contentController.text,
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
      isPinned: _isPinned,
      tags: _tags,
    );

    if (widget.noteId != null) {
      context.read<NotesBloc>().add(UpdateNote(note: note));
    } else {
      context.read<NotesBloc>().add(CreateNote(note: note));
    }

    context.pop();
  }

  void _showOptions(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        decoration: BoxDecoration(
          color: context.colors.surface,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
        ),
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: context.colors.onSurface.withOpacity(0.2),
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(height: 24),
            _OptionTile(
              icon: Icons.share_rounded,
              title: 'Share',
              onTap: () {},
            ),
            _OptionTile(
              icon: Icons.archive_rounded,
              title: 'Archive',
              onTap: () {},
            ),
            _OptionTile(
              icon: Icons.delete_rounded,
              title: 'Delete',
              color: AppTheme.error,
              onTap: () {},
            ),
          ],
        ),
      ),
    );
  }
}

class _ToolbarButton extends StatelessWidget {
  final IconData icon;
  final Color? color;
  final VoidCallback onTap;

  const _ToolbarButton({
    required this.icon,
    this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 40,
        height: 40,
        margin: const EdgeInsets.only(right: 8),
        decoration: BoxDecoration(
          color: AppTheme.darkSurfaceGlass,
          borderRadius: BorderRadius.circular(10),
        ),
        child: Icon(icon, size: 20, color: color),
      ),
    );
  }
}

class _OptionTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final Color? color;
  final VoidCallback onTap;

  const _OptionTile({
    required this.icon,
    required this.title,
    this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      onTap: onTap,
      leading: Icon(icon, color: color),
      title: Text(
        title,
        style: context.textTheme.bodyLarge?.copyWith(color: color),
      ),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
    );
  }
}
