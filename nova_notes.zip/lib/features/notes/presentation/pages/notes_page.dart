import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../../../../core/constants/app_constants.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/utils/extensions.dart';
import '../../domain/entities/note.dart';
import '../bloc/notes_bloc.dart';
import '../widgets/note_card.dart';
import '../widgets/notes_search_bar.dart';
import '../widgets/notes_filter_chips.dart';

/// Notes Page - Smart Notes System
class NotesPage extends StatefulWidget {
  const NotesPage({super.key});

  @override
  State<NotesPage> createState() => _NotesPageState();
}

class _NotesPageState extends State<NotesPage> {
  final _searchController = TextEditingController();
  String? _selectedFolder;
  List<String> _selectedTags = [];
  bool _showArchived = false;

  @override
  void initState() {
    super.initState();
    context.read<NotesBloc>().add(const LoadNotes());
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: context.theme.scaffoldBackgroundColor,
      body: CustomScrollView(
        physics: const BouncingScrollPhysics(),
        slivers: [
          // App Bar
          SliverToBoxAdapter(
            child: Padding(
              padding: EdgeInsets.only(
                left: 24,
                right: 24,
                top: MediaQuery.of(context).padding.top + 16,
                bottom: 16,
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Notes',
                    style: context.textTheme.displayMedium?.copyWith(
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  Row(
                    children: [
                      _IconButton(
                        icon: Icons.folder_rounded,
                        onTap: () {},
                      ),
                      const SizedBox(width: 8),
                      _IconButton(
                        icon: Icons.more_vert_rounded,
                        onTap: () {},
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),

          // Search Bar
          SliverToBoxAdapter(
            child: NotesSearchBar(
              controller: _searchController,
              onSearch: (query) {
                context.read<NotesBloc>().add(SearchNotes(query: query));
              },
              onClear: () {
                _searchController.clear();
                context.read<NotesBloc>().add(const LoadNotes());
              },
            ),
          ),

          // Filter Chips
          SliverToBoxAdapter(
            child: NotesFilterChips(
              selectedTags: _selectedTags,
              showArchived: _showArchived,
              onTagSelected: (tag) {
                setState(() {
                  if (_selectedTags.contains(tag)) {
                    _selectedTags.remove(tag);
                  } else {
                    _selectedTags.add(tag);
                  }
                });
                context.read<NotesBloc>().add(
                  LoadNotes(tags: _selectedTags, showArchived: _showArchived),
                );
              },
              onArchiveToggle: () {
                setState(() => _showArchived = !_showArchived);
                context.read<NotesBloc>().add(
                  LoadNotes(tags: _selectedTags, showArchived: _showArchived),
                );
              },
            ),
          ),

          // Notes List
          BlocBuilder<NotesBloc, NotesState>(
            builder: (context, state) {
              if (state is NotesLoading) {
                return const SliverFillRemaining(
                  child: Center(child: CircularProgressIndicator()),
                );
              }

              if (state is NotesError) {
                return SliverFillRemaining(
                  child: Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.error_outline_rounded,
                          size: 48,
                          color: AppTheme.error.withOpacity(0.5),
                        ),
                        const SizedBox(height: 16),
                        Text(
                          state.message,
                          style: context.textTheme.bodyMedium,
                          textAlign: TextAlign.center,
                        ),
                      ],
                    ),
                  ),
                );
              }

              if (state is NotesLoaded || state is NotesSearchResults) {
                final notes = state is NotesLoaded
                    ? state.notes
                    : (state as NotesSearchResults).notes;

                if (notes.isEmpty) {
                  return SliverFillRemaining(
                    child: _EmptyNotesState(
                      isSearch: state is NotesSearchResults,
                    ),
                  );
                }

                return SliverPadding(
                  padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
                  sliver: SliverList.builder(
                    itemCount: notes.length,
                    itemBuilder: (context, index) {
                      final note = notes[index];
                      return NoteCard(
                        note: note,
                        onTap: () => context.push(
                          '${AppConstants.routeNoteEditor}?id=${note.id}',
                        ),
                        onPin: () => context.read<NotesBloc>().add(
                          TogglePinNote(id: note.id),
                        ),
                        onArchive: () => context.read<NotesBloc>().add(
                          ArchiveNote(id: note.id),
                        ),
                        onDelete: () => context.read<NotesBloc>().add(
                          DeleteNote(id: note.id),
                        ),
                      ).animate()
                        .fadeIn(delay: (index * 50).ms, duration: 300.ms)
                        .slideY(begin: 0.1, end: 0, duration: 300.ms);
                    },
                  ),
                );
              }

              return const SliverFillRemaining(
                child: Center(child: CircularProgressIndicator()),
              );
            },
          ),

          const SliverToBoxAdapter(child: SizedBox(height: 100)),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => context.push(AppConstants.routeNoteEditor),
        icon: const Icon(Icons.add_rounded),
        label: const Text('New Note'),
      ),
    );
  }
}

class _IconButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;

  const _IconButton({required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 40,
        height: 40,
        decoration: BoxDecoration(
          color: AppTheme.darkSurfaceElevated,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: AppTheme.darkBorder),
        ),
        child: Icon(icon, size: 20),
      ),
    );
  }
}

class _EmptyNotesState extends StatelessWidget {
  final bool isSearch;

  const _EmptyNotesState({this.isSearch = false});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 80,
            height: 80,
            decoration: BoxDecoration(
              color: AppTheme.electricBlue.withOpacity(0.1),
              borderRadius: BorderRadius.circular(24),
            ),
            child: Icon(
              isSearch ? Icons.search_off_rounded : Icons.edit_note_rounded,
              size: 36,
              color: AppTheme.electricBlue.withOpacity(0.5),
            ),
          ),
          const SizedBox(height: 24),
          Text(
            isSearch ? 'No notes found' : 'Start writing',
            style: context.textTheme.titleLarge,
          ),
          const SizedBox(height: 8),
          Text(
            isSearch
                ? 'Try a different search term'
                : 'Create your first note and capture your ideas',
            style: context.textTheme.bodyMedium?.copyWith(
              color: AppTheme.textSecondaryDark,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
}
