import 'package:flutter/material.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/utils/extensions.dart';

class NotesFilterChips extends StatelessWidget {
  final List<String> selectedTags;
  final bool showArchived;
  final Function(String) onTagSelected;
  final VoidCallback onArchiveToggle;

  const NotesFilterChips({
    super.key,
    required this.selectedTags,
    required this.showArchived,
    required this.onTagSelected,
    required this.onArchiveToggle,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        physics: const BouncingScrollPhysics(),
        child: Row(
          children: [
            FilterChip(
              label: const Text('Archived'),
              selected: showArchived,
              onSelected: (_) => onArchiveToggle(),
              selectedColor: AppTheme.accentAmber.withOpacity(0.2),
              checkmarkColor: AppTheme.accentAmber,
            ),
            const SizedBox(width: 8),
            ...['Work', 'Personal', 'Ideas', 'Meeting'].map((tag) {
              final isSelected = selectedTags.contains(tag);
              return Padding(
                padding: const EdgeInsets.only(right: 8),
                child: FilterChip(
                  label: Text(tag),
                  selected: isSelected,
                  onSelected: (_) => onTagSelected(tag),
                  selectedColor: AppTheme.electricBlue.withOpacity(0.2),
                  checkmarkColor: AppTheme.electricBlue,
                ),
              );
            }).toList(),
          ],
        ),
      ),
    );
  }
}
