import 'package:flutter/material.dart';
import 'package:flutter_slidable/flutter_slidable.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/utils/extensions.dart';
import '../../domain/entities/note.dart';

/// Premium note card with swipe actions
class NoteCard extends StatelessWidget {
  final Note note;
  final VoidCallback onTap;
  final VoidCallback onPin;
  final VoidCallback onArchive;
  final VoidCallback onDelete;

  const NoteCard({
    super.key,
    required this.note,
    required this.onTap,
    required this.onPin,
    required this.onArchive,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Slidable(
        endActionPane: ActionPane(
          motion: const DrawerMotion(),
          extentRatio: 0.6,
          children: [
            CustomSlidableAction(
              onPressed: (_) => onPin(),
              backgroundColor: AppTheme.accentAmber.withOpacity(0.2),
              foregroundColor: AppTheme.accentAmber,
              borderRadius: const BorderRadius.horizontal(left: Radius.circular(16)),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    note.isPinned ? Icons.push_pin_rounded : Icons.push_pin_outlined,
                    size: 24,
                  ),
                  const SizedBox(height: 4),
                  Text(
                    note.isPinned ? 'Unpin' : 'Pin',
                    style: context.textTheme.labelSmall,
                  ),
                ],
              ),
            ),
            CustomSlidableAction(
              onPressed: (_) => onArchive(),
              backgroundColor: AppTheme.electricBlue.withOpacity(0.2),
              foregroundColor: AppTheme.electricBlue,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    note.isArchived ? Icons.unarchive_rounded : Icons.archive_rounded,
                    size: 24,
                  ),
                  const SizedBox(height: 4),
                  Text(
                    note.isArchived ? 'Restore' : 'Archive',
                    style: context.textTheme.labelSmall,
                  ),
                ],
              ),
            ),
            CustomSlidableAction(
              onPressed: (_) => onDelete(),
              backgroundColor: AppTheme.error.withOpacity(0.2),
              foregroundColor: AppTheme.error,
              borderRadius: const BorderRadius.horizontal(right: Radius.circular(16)),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.delete_rounded, size: 24),
                  const SizedBox(height: 4),
                  Text(
                    'Delete',
                    style: context.textTheme.labelSmall,
                  ),
                ],
              ),
            ),
          ],
        ),
        child: GestureDetector(
          onTap: onTap,
          child: Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: AppTheme.darkSurfaceElevated,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: note.isPinned
                    ? AppTheme.accentAmber.withOpacity(0.3)
                    : AppTheme.darkBorder.withOpacity(0.5),
                width: note.isPinned ? 1.5 : 0.5,
              ),
              boxShadow: note.isPinned ? AppTheme.elevatedShadow : AppTheme.softShadow,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    if (note.isPinned)
                      Container(
                        margin: const EdgeInsets.only(right: 8),
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: AppTheme.accentAmber.withOpacity(0.15),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(
                              Icons.push_pin_rounded,
                              size: 12,
                              color: AppTheme.accentAmber,
                            ),
                            const SizedBox(width: 4),
                            Text(
                              'Pinned',
                              style: context.textTheme.labelSmall?.copyWith(
                                color: AppTheme.accentAmber,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ],
                        ),
                      ),
                    if (note.isOffline)
                      Container(
                        margin: const EdgeInsets.only(right: 8),
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: AppTheme.textTertiaryDark.withOpacity(0.15),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(
                              Icons.cloud_off_rounded,
                              size: 12,
                              color: AppTheme.textTertiaryDark,
                            ),
                            const SizedBox(width: 4),
                            Text(
                              'Offline',
                              style: context.textTheme.labelSmall?.copyWith(
                                color: AppTheme.textTertiaryDark,
                              ),
                            ),
                          ],
                        ),
                      ),
                    const Spacer(),
                    Text(
                      note.updatedAt.relativeTime,
                      style: context.textTheme.labelSmall?.copyWith(
                        color: AppTheme.textTertiaryDark,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Text(
                  note.title,
                  style: context.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
                if (note.plainText?.isNotEmpty ?? false) ...[
                  const SizedBox(height: 8),
                  Text(
                    note.plainText!,
                    style: context.textTheme.bodyMedium?.copyWith(
                      color: AppTheme.textSecondaryDark,
                    ),
                    maxLines: 3,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
                if (note.tags.isNotEmpty || note.attachments.isNotEmpty) ...[
                  const SizedBox(height: 12),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      ...note.tags.map((tag) => _TagChip(label: tag)),
                      if (note.attachments.isNotEmpty)
                        _TagChip(
                          label: '${note.attachments.length} attachments',
                          icon: Icons.attach_file_rounded,
                        ),
                    ],
                  ),
                ],
                if (note.aiSummary?.isNotEmpty ?? false) ...[
                  const SizedBox(height: 12),
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: AppTheme.deepPurple.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: AppTheme.deepPurple.withOpacity(0.2),
                      ),
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Icon(
                          Icons.auto_awesome_rounded,
                          size: 16,
                          color: AppTheme.deepPurpleLight,
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            note.aiSummary!,
                            style: context.textTheme.labelMedium?.copyWith(
                              color: AppTheme.deepPurpleLight,
                            ),
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _TagChip extends StatelessWidget {
  final String label;
  final IconData? icon;

  const _TagChip({required this.label, this.icon});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: AppTheme.darkSurfaceGlass,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: AppTheme.darkBorder.withOpacity(0.5)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (icon != null) ...[
            Icon(icon, size: 12, color: AppTheme.textTertiaryDark),
            const SizedBox(width: 4),
          ],
          Text(
            label,
            style: context.textTheme.labelSmall?.copyWith(
              color: AppTheme.textSecondaryDark,
            ),
          ),
        ],
      ),
    );
  }
}
