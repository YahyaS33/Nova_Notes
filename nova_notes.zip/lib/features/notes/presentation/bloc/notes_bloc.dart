import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import '../../../../core/errors/failures.dart';
import '../../domain/entities/note.dart';
import '../../domain/repositories/note_repository.dart';

part 'notes_event.dart';
part 'notes_state.dart';

/// Notes BLoC - State management for notes feature
class NotesBloc extends Bloc<NotesEvent, NotesState> {
  final NoteRepository _repository;

  NotesBloc({required NoteRepository repository})
      : _repository = repository,
        super(const NotesInitial()) {
    on<LoadNotes>(_onLoadNotes);
    on<LoadPinnedNotes>(_onLoadPinnedNotes);
    on<CreateNote>(_onCreateNote);
    on<UpdateNote>(_onUpdateNote);
    on<DeleteNote>(_onDeleteNote);
    on<TogglePinNote>(_onTogglePin);
    on<SearchNotes>(_onSearchNotes);
    on<ArchiveNote>(_onArchiveNote);
  }

  Future<void> _onLoadNotes(LoadNotes event, Emitter<NotesState> emit) async {
    emit(const NotesLoading());
    final result = await _repository.getNotes(
      folderId: event.folderId,
      tags: event.tags,
      isArchived: event.showArchived,
    );
    result.fold(
      (failure) => emit(NotesError(message: _mapFailureToMessage(failure))),
      (notes) => emit(NotesLoaded(notes: notes)),
    );
  }

  Future<void> _onLoadPinnedNotes(
    LoadPinnedNotes event,
    Emitter<NotesState> emit,
  ) async {
    emit(const NotesLoading());
    final result = await _repository.getPinnedNotes();
    result.fold(
      (failure) => emit(NotesError(message: _mapFailureToMessage(failure))),
      (notes) => emit(PinnedNotesLoaded(notes: notes)),
    );
  }

  Future<void> _onCreateNote(
    CreateNote event,
    Emitter<NotesState> emit,
  ) async {
    emit(const NotesLoading());
    final result = await _repository.createNote(event.note);
    result.fold(
      (failure) => emit(NotesError(message: _mapFailureToMessage(failure))),
      (note) {
        emit(NoteCreated(note: note));
        add(const LoadNotes());
      },
    );
  }

  Future<void> _onUpdateNote(
    UpdateNote event,
    Emitter<NotesState> emit,
  ) async {
    emit(const NotesLoading());
    final result = await _repository.updateNote(event.note);
    result.fold(
      (failure) => emit(NotesError(message: _mapFailureToMessage(failure))),
      (note) {
        emit(NoteUpdated(note: note));
        add(const LoadNotes());
      },
    );
  }

  Future<void> _onDeleteNote(
    DeleteNote event,
    Emitter<NotesState> emit,
  ) async {
    emit(const NotesLoading());
    final result = await _repository.deleteNote(event.id);
    result.fold(
      (failure) => emit(NotesError(message: _mapFailureToMessage(failure))),
      (_) {
        emit(const NoteDeleted());
        add(const LoadNotes());
      },
    );
  }

  Future<void> _onTogglePin(
    TogglePinNote event,
    Emitter<NotesState> emit,
  ) async {
    final result = await _repository.togglePin(event.id);
    result.fold(
      (failure) => emit(NotesError(message: _mapFailureToMessage(failure))),
      (note) {
        emit(NoteUpdated(note: note));
        add(const LoadNotes());
      },
    );
  }

  Future<void> _onSearchNotes(
    SearchNotes event,
    Emitter<NotesState> emit,
  ) async {
    if (event.query.isEmpty) {
      add(const LoadNotes());
      return;
    }
    emit(const NotesLoading());
    final result = await _repository.searchNotes(event.query);
    result.fold(
      (failure) => emit(NotesError(message: _mapFailureToMessage(failure))),
      (notes) => emit(NotesSearchResults(notes: notes, query: event.query)),
    );
  }

  Future<void> _onArchiveNote(
    ArchiveNote event,
    Emitter<NotesState> emit,
  ) async {
    final result = await _repository.toggleArchive(event.id);
    result.fold(
      (failure) => emit(NotesError(message: _mapFailureToMessage(failure))),
      (note) {
        emit(NoteUpdated(note: note));
        add(const LoadNotes());
      },
    );
  }

  String _mapFailureToMessage(Failure failure) {
    switch (failure.runtimeType) {
      case ServerFailure:
        return 'Server error. Please try again.';
      case CacheFailure:
        return 'Cache error. Data may be outdated.';
      case NetworkFailure:
        return 'No internet connection. Working offline.';
      case AuthFailure:
        return 'Authentication failed. Please sign in again.';
      case NotFoundFailure:
        return 'Note not found.';
      default:
        return 'An unexpected error occurred.';
    }
  }
}
