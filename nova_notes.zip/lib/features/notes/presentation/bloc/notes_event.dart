part of 'notes_bloc.dart';

abstract class NotesEvent extends Equatable {
  const NotesEvent();

  @override
  List<Object?> get props => [];
}

class LoadNotes extends NotesEvent {
  final String? folderId;
  final List<String>? tags;
  final bool showArchived;

  const LoadNotes({this.folderId, this.tags, this.showArchived = false});

  @override
  List<Object?> get props => [folderId, tags, showArchived];
}

class LoadPinnedNotes extends NotesEvent {
  const LoadPinnedNotes();
}

class CreateNote extends NotesEvent {
  final Note note;

  const CreateNote({required this.note});

  @override
  List<Object?> get props => [note];
}

class UpdateNote extends NotesEvent {
  final Note note;

  const UpdateNote({required this.note});

  @override
  List<Object?> get props => [note];
}

class DeleteNote extends NotesEvent {
  final String id;

  const DeleteNote({required this.id});

  @override
  List<Object?> get props => [id];
}

class TogglePinNote extends NotesEvent {
  final String id;

  const TogglePinNote({required this.id});

  @override
  List<Object?> get props => [id];
}

class SearchNotes extends NotesEvent {
  final String query;

  const SearchNotes({required this.query});

  @override
  List<Object?> get props => [query];
}

class ArchiveNote extends NotesEvent {
  final String id;

  const ArchiveNote({required this.id});

  @override
  List<Object?> get props => [id];
}
