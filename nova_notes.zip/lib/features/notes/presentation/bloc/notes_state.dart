part of 'notes_bloc.dart';

abstract class NotesState extends Equatable {
  const NotesState();

  @override
  List<Object?> get props => [];
}

class NotesInitial extends NotesState {
  const NotesInitial();
}

class NotesLoading extends NotesState {
  const NotesLoading();
}

class NotesLoaded extends NotesState {
  final List<Note> notes;

  const NotesLoaded({required this.notes});

  @override
  List<Object?> get props => [notes];
}

class PinnedNotesLoaded extends NotesState {
  final List<Note> notes;

  const PinnedNotesLoaded({required this.notes});

  @override
  List<Object?> get props => [notes];
}

class NotesSearchResults extends NotesState {
  final List<Note> notes;
  final String query;

  const NotesSearchResults({required this.notes, required this.query});

  @override
  List<Object?> get props => [notes, query];
}

class NoteCreated extends NotesState {
  final Note note;

  const NoteCreated({required this.note});

  @override
  List<Object?> get props => [note];
}

class NoteUpdated extends NotesState {
  final Note note;

  const NoteUpdated({required this.note});

  @override
  List<Object?> get props => [note];
}

class NoteDeleted extends NotesState {
  const NoteDeleted();
}

class NotesError extends NotesState {
  final String message;

  const NotesError({required this.message});

  @override
  List<Object?> get props => [message];
}
