import 'package:dartz/dartz.dart';
import '../../../../core/errors/failures.dart';
import '../../../../core/services/connectivity_service.dart';
import '../../domain/entities/note.dart';
import '../../domain/repositories/note_repository.dart';
import '../datasources/note_local_datasource.dart';
import '../datasources/note_remote_datasource.dart';
import '../models/note_model.dart';

/// Note Repository Implementation - Offline-first strategy
class NoteRepositoryImpl implements NoteRepository {
  final NoteRemoteDataSource _remote;
  final NoteLocalDataSource _local;
  final ConnectivityService _connectivity;

  NoteRepositoryImpl({
    required NoteRemoteDataSource remote,
    required NoteLocalDataSource local,
    required ConnectivityService connectivity,
  })  : _remote = remote,
        _local = local,
        _connectivity = connectivity;

  Future<bool> get _isOnline => _connectivity.isConnected;

  @override
  Future<Either<Failure, List<Note>>> getNotes({
    String? folderId,
    List<String>? tags,
    bool? isPinned,
    bool? isArchived,
    String? searchQuery,
  }) async {
    try {
      if (await _isOnline) {
        final remoteNotes = await _remote.getNotes(
          folderId: folderId,
          tags: tags,
          isPinned: isPinned,
          isArchived: isArchived,
        );
        await _local.saveNotes(remoteNotes);
        return Right(remoteNotes);
      } else {
        final localNotes = await _local.getNotes();
        return Right(localNotes);
      }
    } catch (e) {
      try {
        final localNotes = await _local.getNotes();
        return Right(localNotes);
      } catch (_) {
        return Left(ServerFailure(message: e.toString()));
      }
    }
  }

  @override
  Future<Either<Failure, Note>> getNoteById(String id) async {
    try {
      if (await _isOnline) {
        final note = await _remote.getNoteById(id);
        if (note != null) {
          await _local.saveNote(note);
          return Right(note);
        }
      }
      final localNote = await _local.getNoteById(id);
      if (localNote != null) return Right(localNote);
      return const Left(NotFoundFailure());
    } catch (e) {
      return Left(ServerFailure(message: e.toString()));
    }
  }

  @override
  Future<Either<Failure, Note>> createNote(Note note) async {
    try {
      final model = NoteModel.fromEntity(note).copyWithModel(isOffline: !(await _isOnline));
      await _local.saveNote(model);
      if (await _isOnline) {
        await _remote.createNote(model.copyWithModel(isOffline: false));
      }
      return Right(model);
    } catch (e) {
      return Left(ServerFailure(message: e.toString()));
    }
  }

  @override
  Future<Either<Failure, Note>> updateNote(Note note) async {
    try {
      final model = NoteModel.fromEntity(note).copyWithModel(
        updatedAt: DateTime.now(),
        isOffline: !(await _isOnline),
      );
      await _local.saveNote(model);
      if (await _isOnline) {
        await _remote.updateNote(model.copyWithModel(isOffline: false));
      }
      return Right(model);
    } catch (e) {
      return Left(ServerFailure(message: e.toString()));
    }
  }

  @override
  Future<Either<Failure, Unit>> deleteNote(String id) async {
    try {
      await _local.deleteNote(id);
      if (await _isOnline) {
        await _remote.deleteNote(id);
      }
      return const Right(unit);
    } catch (e) {
      return Left(ServerFailure(message: e.toString()));
    }
  }

  @override
  Future<Either<Failure, Note>> togglePin(String id) async {
    final result = await getNoteById(id);
    return result.fold(
      (failure) => Left(failure),
      (note) => updateNote(note.copyWith(isPinned: !note.isPinned)),
    );
  }

  @override
  Future<Either<Failure, Note>> toggleArchive(String id) async {
    final result = await getNoteById(id);
    return result.fold(
      (failure) => Left(failure),
      (note) => updateNote(note.copyWith(isArchived: !note.isArchived)),
    );
  }

  @override
  Future<Either<Failure, List<Note>>> getPinnedNotes() async {
    return getNotes(isPinned: true, isArchived: false);
  }

  @override
  Future<Either<Failure, List<Note>>> getRecentNotes({int limit = 5}) async {
    final result = await getNotes();
    return result.map((notes) => notes.take(limit).toList());
  }

  @override
  Future<Either<Failure, List<Note>>> searchNotes(String query) async {
    try {
      if (await _isOnline) {
        final results = await _remote.searchNotes(query);
        return Right(results);
      }
      final localNotes = await _local.getNotes();
      final filtered = localNotes.where((n) {
        return n.title.toLowerCase().contains(query.toLowerCase()) ||
            (n.plainText?.toLowerCase().contains(query.toLowerCase()) ?? false);
      }).toList();
      return Right(filtered);
    } catch (e) {
      return Left(ServerFailure(message: e.toString()));
    }
  }

  @override
  Stream<Either<Failure, List<Note>>> watchNotes() {
    return _remote.watchNotes().map((notes) => Right<Failure, List<Note>>(notes));
  }

  @override
  Future<Either<Failure, Unit>> syncOfflineNotes() async {
    try {
      final localNotes = await _local.getNotes();
      final offlineNotes = localNotes.where((n) => n.isOffline).toList();

      for (final note in offlineNotes) {
        await _remote.createNote(note.copyWithModel(isOffline: false));
      }
      return const Right(unit);
    } catch (e) {
      return Left(NetworkFailure(message: e.toString()));
    }
  }

  @override
  Future<Either<Failure, List<Folder>>> getFolders() async {
    // Implementation for folders
    return const Right([]);
  }

  @override
  Future<Either<Failure, Folder>> createFolder(Folder folder) async {
    return const Left(ServerFailure(message: 'Not implemented'));
  }

  @override
  Future<Either<Failure, List<Tag>>> getTags() async {
    // Implementation for tags
    return const Right([]);
  }

  @override
  Future<Either<Failure, String>> generateSummary(String noteId) async {
    return const Left(ServerFailure(message: 'AI not configured'));
  }

  @override
  Future<Either<Failure, List<String>>> extractTasks(String noteId) async {
    return const Left(ServerFailure(message: 'AI not configured'));
  }
}
