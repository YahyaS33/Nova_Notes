import 'package:cloud_firestore/cloud_firestore.dart';
import '../../domain/entities/note.dart';

/// NoteModel - Data layer representation
class NoteModel extends Note {
  const NoteModel({
    required super.id,
    required super.title,
    required super.content,
    super.plainText,
    required super.createdAt,
    required super.updatedAt,
    super.isPinned,
    super.isArchived,
    super.folderId,
    super.tags,
    super.attachments,
    super.aiSummary,
    super.extractedTasks,
    super.color,
    super.isOffline,
    super.reminderDate,
  });

  factory NoteModel.fromJson(Map<String, dynamic> json) {
    return NoteModel(
      id: json['id'] as String,
      title: json['title'] as String,
      content: json['content'] as String,
      plainText: json['plainText'] as String?,
      createdAt: (json['createdAt'] as Timestamp).toDate(),
      updatedAt: (json['updatedAt'] as Timestamp).toDate(),
      isPinned: json['isPinned'] as bool? ?? false,
      isArchived: json['isArchived'] as bool? ?? false,
      folderId: json['folderId'] as String?,
      tags: List<String>.from(json['tags'] ?? []),
      attachments: List<String>.from(json['attachments'] ?? []),
      aiSummary: json['aiSummary'] as String?,
      extractedTasks: List<String>.from(json['extractedTasks'] ?? []),
      color: json['color'] as String?,
      isOffline: json['isOffline'] as bool? ?? false,
      reminderDate: json['reminderDate'] != null
          ? (json['reminderDate'] as Timestamp).toDate()
          : null,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'content': content,
      'plainText': plainText,
      'createdAt': Timestamp.fromDate(createdAt),
      'updatedAt': Timestamp.fromDate(updatedAt),
      'isPinned': isPinned,
      'isArchived': isArchived,
      'folderId': folderId,
      'tags': tags,
      'attachments': attachments,
      'aiSummary': aiSummary,
      'extractedTasks': extractedTasks,
      'color': color,
      'isOffline': isOffline,
      'reminderDate': reminderDate != null
          ? Timestamp.fromDate(reminderDate!)
          : null,
    };
  }

  factory NoteModel.fromEntity(Note note) {
    return NoteModel(
      id: note.id,
      title: note.title,
      content: note.content,
      plainText: note.plainText,
      createdAt: note.createdAt,
      updatedAt: note.updatedAt,
      isPinned: note.isPinned,
      isArchived: note.isArchived,
      folderId: note.folderId,
      tags: note.tags,
      attachments: note.attachments,
      aiSummary: note.aiSummary,
      extractedTasks: note.extractedTasks,
      color: note.color,
      isOffline: note.isOffline,
      reminderDate: note.reminderDate,
    );
  }

  NoteModel copyWithModel({
    String? id,
    String? title,
    String? content,
    String? plainText,
    DateTime? createdAt,
    DateTime? updatedAt,
    bool? isPinned,
    bool? isArchived,
    String? folderId,
    List<String>? tags,
    List<String>? attachments,
    String? aiSummary,
    List<String>? extractedTasks,
    String? color,
    bool? isOffline,
    DateTime? reminderDate,
  }) {
    return NoteModel(
      id: id ?? this.id,
      title: title ?? this.title,
      content: content ?? this.content,
      plainText: plainText ?? this.plainText,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      isPinned: isPinned ?? this.isPinned,
      isArchived: isArchived ?? this.isArchived,
      folderId: folderId ?? this.folderId,
      tags: tags ?? this.tags,
      attachments: attachments ?? this.attachments,
      aiSummary: aiSummary ?? this.aiSummary,
      extractedTasks: extractedTasks ?? this.extractedTasks,
      color: color ?? this.color,
      isOffline: isOffline ?? this.isOffline,
      reminderDate: reminderDate ?? this.reminderDate,
    );
  }
}
