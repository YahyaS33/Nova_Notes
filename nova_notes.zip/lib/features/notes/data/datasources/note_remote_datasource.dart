import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart' as firebase_auth;
import '../../../../core/constants/app_constants.dart';
import '../models/note_model.dart';

/// Remote datasource for notes using Firestore
abstract class NoteRemoteDataSource {
  Future<List<NoteModel>> getNotes({
    String? folderId,
    List<String>? tags,
    bool? isPinned,
    bool? isArchived,
  });
  Future<NoteModel?> getNoteById(String id);
  Future<NoteModel> createNote(NoteModel note);
  Future<NoteModel> updateNote(NoteModel note);
  Future<void> deleteNote(String id);
  Future<List<NoteModel>> searchNotes(String query);
  Stream<List<NoteModel>> watchNotes();
}

class NoteRemoteDataSourceImpl implements NoteRemoteDataSource {
  final FirebaseFirestore _firestore;
  final firebase_auth.FirebaseAuth _auth;

  NoteRemoteDataSourceImpl({
    FirebaseFirestore? firestore,
    firebase_auth.FirebaseAuth? auth,
  })  : _firestore = firestore ?? FirebaseFirestore.instance,
        _auth = auth ?? firebase_auth.FirebaseAuth.instance;

  String? get _userId => _auth.currentUser?.uid;

  CollectionReference<Map<String, dynamic>> get _notesCollection {
    if (_userId == null) throw Exception('User not authenticated');
    return _firestore
        .collection(AppConstants.collectionUsers)
        .doc(_userId)
        .collection(AppConstants.collectionNotes);
  }

  @override
  Future<List<NoteModel>> getNotes({
    String? folderId,
    List<String>? tags,
    bool? isPinned,
    bool? isArchived,
  }) async {
    Query<Map<String, dynamic>> query = _notesCollection
        .orderBy('updatedAt', descending: true);

    if (isArchived != null) {
      query = query.where('isArchived', isEqualTo: isArchived);
    }
    if (isPinned != null) {
      query = query.where('isPinned', isEqualTo: isPinned);
    }
    if (folderId != null) {
      query = query.where('folderId', isEqualTo: folderId);
    }
    if (tags != null && tags.isNotEmpty) {
      query = query.where('tags', arrayContainsAny: tags);
    }

    final snapshot = await query.get();
    return snapshot.docs.map((doc) => NoteModel.fromJson(doc.data())).toList();
  }

  @override
  Future<NoteModel?> getNoteById(String id) async {
    final doc = await _notesCollection.doc(id).get();
    if (!doc.exists) return null;
    return NoteModel.fromJson(doc.data()!);
  }

  @override
  Future<NoteModel> createNote(NoteModel note) async {
    final docRef = _notesCollection.doc(note.id);
    await docRef.set(note.toJson());
    return note;
  }

  @override
  Future<NoteModel> updateNote(NoteModel note) async {
    final updated = note.copyWithModel(updatedAt: DateTime.now());
    await _notesCollection.doc(note.id).update(updated.toJson());
    return updated;
  }

  @override
  Future<void> deleteNote(String id) async {
    await _notesCollection.doc(id).delete();
  }

  @override
  Future<List<NoteModel>> searchNotes(String query) async {
    final snapshot = await _notesCollection.get();
    final allNotes = snapshot.docs.map((d) => NoteModel.fromJson(d.data()));
    final lowerQuery = query.toLowerCase();

    return allNotes.where((note) {
      return note.title.toLowerCase().contains(lowerQuery) ||
          (note.plainText?.toLowerCase().contains(lowerQuery) ?? false) ||
          note.tags.any((t) => t.toLowerCase().contains(lowerQuery));
    }).toList();
  }

  @override
  Stream<List<NoteModel>> watchNotes() {
    return _notesCollection
        .orderBy('updatedAt', descending: true)
        .snapshots()
        .map((snapshot) =>
            snapshot.docs.map((doc) => NoteModel.fromJson(doc.data())).toList());
  }
}
