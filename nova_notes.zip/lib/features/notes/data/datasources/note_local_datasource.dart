import 'package:hive/hive.dart';
import '../models/note_model.dart';

/// Local datasource for offline-first note storage
abstract class NoteLocalDataSource {
  Future<List<NoteModel>> getNotes();
  Future<NoteModel?> getNoteById(String id);
  Future<void> saveNote(NoteModel note);
  Future<void> deleteNote(String id);
  Future<void> saveNotes(List<NoteModel> notes);
  Future<void> clearCache();
}

class NoteLocalDataSourceImpl implements NoteLocalDataSource {
  final Box<Map<String, dynamic>> _box;

  NoteLocalDataSourceImpl({required Box<Map<String, dynamic>> box}) : _box = box;

  @override
  Future<List<NoteModel>> getNotes() async {
    final notes = _box.values.map((json) => NoteModel.fromJson(json)).toList();
    notes.sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
    return notes;
  }

  @override
  Future<NoteModel?> getNoteById(String id) async {
    final json = _box.get(id);
    if (json == null) return null;
    return NoteModel.fromJson(json);
  }

  @override
  Future<void> saveNote(NoteModel note) async {
    await _box.put(note.id, note.toJson());
  }

  @override
  Future<void> deleteNote(String id) async {
    await _box.delete(id);
  }

  @override
  Future<void> saveNotes(List<NoteModel> notes) async {
    final Map<String, Map<String, dynamic>> entries = {
      for (var note in notes) note.id: note.toJson(),
    };
    await _box.putAll(entries);
  }

  @override
  Future<void> clearCache() async {
    await _box.clear();
  }
}
