part of 'calendar_bloc.dart';

abstract class CalendarEvent extends Equatable {
  const CalendarEvent();
  @override
  List<Object?> get props => [];
}

class LoadTodayEvents extends CalendarEvent {
  const LoadTodayEvents();
}

class LoadEventsForDate extends CalendarEvent {
  final DateTime date;
  const LoadEventsForDate(this.date);
  @override
  List<Object?> get props => [date];
}

class CreateEvent extends CalendarEvent {
  final CalendarEvent event;
  const CreateEvent(this.event);
  @override
  List<Object?> get props => [event];
}

class UpdateEvent extends CalendarEvent {
  final CalendarEvent event;
  const UpdateEvent(this.event);
  @override
  List<Object?> get props => [event];
}

class DeleteEvent extends CalendarEvent {
  final String id;
  const DeleteEvent(this.id);
  @override
  List<Object?> get props => [id];
}
