import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import '../../domain/entities/event.dart';

part 'calendar_event.dart';
part 'calendar_state.dart';

class CalendarBloc extends Bloc<CalendarEvent, CalendarState> {
  CalendarBloc() : super(CalendarInitial()) {
    on<LoadTodayEvents>(_onLoadTodayEvents);
    on<LoadEventsForDate>(_onLoadEventsForDate);
    on<CreateEvent>(_onCreateEvent);
    on<UpdateEvent>(_onUpdateEvent);
    on<DeleteEvent>(_onDeleteEvent);
  }

  Future<void> _onLoadTodayEvents(
    LoadTodayEvents event,
    Emitter<CalendarState> emit,
  ) async {
    emit(CalendarLoading());
    // TODO: Load from repository
    emit(const CalendarEventsLoaded(events: []));
  }

  Future<void> _onLoadEventsForDate(
    LoadEventsForDate event,
    Emitter<CalendarState> emit,
  ) async {
    emit(CalendarLoading());
    // TODO: Load from repository
    emit(const CalendarEventsLoaded(events: []));
  }

  Future<void> _onCreateEvent(
    CreateEvent event,
    Emitter<CalendarState> emit,
  ) async {
    // TODO: Create event
  }

  Future<void> _onUpdateEvent(
    UpdateEvent event,
    Emitter<CalendarState> emit,
  ) async {
    // TODO: Update event
  }

  Future<void> _onDeleteEvent(
    DeleteEvent event,
    Emitter<CalendarState> emit,
  ) async {
    // TODO: Delete event
  }
}
