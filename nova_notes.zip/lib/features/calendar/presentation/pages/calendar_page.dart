import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:table_calendar/table_calendar.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/utils/extensions.dart';
import '../../domain/entities/event.dart';
import '../bloc/calendar_bloc.dart';

/// Calendar Page - Elegant scheduling system
class CalendarPage extends StatefulWidget {
  const CalendarPage({super.key});

  @override
  State<CalendarPage> createState() => _CalendarPageState();
}

class _CalendarPageState extends State<CalendarPage> {
  CalendarFormat _calendarFormat = CalendarFormat.month;
  DateTime _focusedDay = DateTime.now();
  DateTime? _selectedDay;

  @override
  void initState() {
    super.initState();
    _selectedDay = _focusedDay;
    context.read<CalendarBloc>().add(LoadEventsForDate(_focusedDay));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: context.theme.scaffoldBackgroundColor,
      body: CustomScrollView(
        physics: const BouncingScrollPhysics(),
        slivers: [
          SliverToBoxAdapter(
            child: Padding(
              padding: EdgeInsets.only(
                left: 24,
                right: 24,
                top: MediaQuery.of(context).padding.top + 16,
                bottom: 16,
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Calendar',
                    style: context.textTheme.displayMedium?.copyWith(
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  Row(
                    children: [
                      _CalendarViewToggle(
                        format: _calendarFormat,
                        onToggle: () {
                          setState(() {
                            _calendarFormat = _calendarFormat == CalendarFormat.month
                                ? CalendarFormat.week
                                : CalendarFormat.month;
                          });
                        },
                      ),
                      const SizedBox(width: 8),
                      _IconButton(
                        icon: Icons.add_rounded,
                        onTap: () => _showAddEventDialog(context),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),

          // Calendar Widget
          SliverToBoxAdapter(
            child: Container(
              margin: const EdgeInsets.symmetric(horizontal: 16),
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AppTheme.darkSurfaceElevated,
                borderRadius: BorderRadius.circular(24),
                border: Border.all(color: AppTheme.darkBorder.withOpacity(0.5)),
              ),
              child: TableCalendar<CalendarEvent>(
                firstDay: DateTime.utc(2020, 1, 1),
                lastDay: DateTime.utc(2030, 12, 31),
                focusedDay: _focusedDay,
                selectedDayPredicate: (day) => isSameDay(_selectedDay, day),
                calendarFormat: _calendarFormat,
                startingDayOfWeek: StartingDayOfWeek.monday,
                headerStyle: HeaderStyle(
                  titleCentered: true,
                  formatButtonVisible: false,
                  titleTextStyle: context.textTheme.titleLarge!,
                  leftChevronIcon: const Icon(Icons.chevron_left_rounded, size: 24),
                  rightChevronIcon: const Icon(Icons.chevron_right_rounded, size: 24),
                  headerPadding: const EdgeInsets.symmetric(vertical: 8),
                ),
                daysOfWeekStyle: DaysOfWeekStyle(
                  weekdayStyle: context.textTheme.labelMedium!,
                  weekendStyle: context.textTheme.labelMedium!.copyWith(
                    color: AppTheme.accentRose,
                  ),
                ),
                calendarStyle: CalendarStyle(
                  outsideDaysVisible: false,
                  weekendTextStyle: context.textTheme.bodyMedium!,
                  defaultTextStyle: context.textTheme.bodyMedium!,
                  todayTextStyle: context.textTheme.bodyMedium!.copyWith(
                    color: AppTheme.electricBlue,
                    fontWeight: FontWeight.w700,
                  ),
                  todayDecoration: BoxDecoration(
                    color: AppTheme.electricBlue.withOpacity(0.15),
                    shape: BoxShape.circle,
                  ),
                  selectedTextStyle: context.textTheme.bodyMedium!.copyWith(
                    color: Colors.white,
                    fontWeight: FontWeight.w700,
                  ),
                  selectedDecoration: BoxDecoration(
                    gradient: AppTheme.primaryGradient,
                    shape: BoxShape.circle,
                  ),
                  cellMargin: const EdgeInsets.all(6),
                  cellPadding: const EdgeInsets.all(8),
                  markersMaxCount: 3,
                  markerSize: 6,
                  markerDecoration: BoxDecoration(
                    color: AppTheme.electricBlue,
                    shape: BoxShape.circle,
                  ),
                  markersAutoAligned: true,
                  markerMargin: const EdgeInsets.symmetric(horizontal: 1),
                ),
                onDaySelected: (selectedDay, focusedDay) {
                  setState(() {
                    _selectedDay = selectedDay;
                    _focusedDay = focusedDay;
                  });
                  context.read<CalendarBloc>().add(LoadEventsForDate(selectedDay));
                },
                onFormatChanged: (format) {
                  setState(() => _calendarFormat = format);
                },
                onPageChanged: (focusedDay) {
                  _focusedDay = focusedDay;
                },
                eventLoader: (day) {
                  // TODO: Load events for day
                  return [];
                },
              ),
            ).animate()
              .fadeIn(duration: 400.ms)
              .slideY(begin: 0.2, end: 0, duration: 400.ms),
          ),

          // Events for Selected Day
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    _selectedDay?.formattedDate ?? 'Today',
                    style: context.textTheme.titleLarge?.copyWith(
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  Text(
                    '${_selectedDay?.dayName ?? ''}',
                    style: context.textTheme.labelLarge?.copyWith(
                      color: AppTheme.textSecondaryDark,
                    ),
                  ),
                ],
              ),
            ),
          ),

          BlocBuilder<CalendarBloc, CalendarState>(
            builder: (context, state) {
              if (state is CalendarEventsLoaded) {
                if (state.events.isEmpty) {
                  return SliverToBoxAdapter(
                    child: _EmptyEventsState(
                      date: _selectedDay ?? DateTime.now(),
                    ),
                  );
                }

                return SliverPadding(
                  padding: const EdgeInsets.symmetric(horizontal: 24),
                  sliver: SliverList.builder(
                    itemCount: state.events.length,
                    itemBuilder: (context, index) {
                      final event = state.events[index];
                      return _EventCard(
                        event: event,
                        onTap: () {},
                      ).animate()
                        .fadeIn(delay: (index * 100).ms, duration: 300.ms)
                        .slideX(begin: 0.2, end: 0, duration: 300.ms);
                    },
                  ),
                );
              }

              return const SliverToBoxAdapter(
                child: Center(child: CircularProgressIndicator()),
              );
            },
          ),

          const SliverToBoxAdapter(child: SizedBox(height: 100)),
        ],
      ),
    );
  }

  void _showAddEventDialog(BuildContext context) {
    // TODO: Implement event creation dialog
  }
}

class _CalendarViewToggle extends StatelessWidget {
  final CalendarFormat format;
  final VoidCallback onToggle;

  const _CalendarViewToggle({required this.format, required this.onToggle});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onToggle,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: AppTheme.darkSurfaceElevated,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: AppTheme.darkBorder),
        ),
        child: Text(
          format == CalendarFormat.month ? 'Month' : 'Week',
          style: context.textTheme.labelMedium?.copyWith(
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
    );
  }
}

class _IconButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;

  const _IconButton({required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 40,
        height: 40,
        decoration: BoxDecoration(
          gradient: AppTheme.primaryGradient,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Icon(icon, color: Colors.white, size: 20),
      ),
    );
  }
}

class _EventCard extends StatelessWidget {
  final CalendarEvent event;
  final VoidCallback onTap;

  const _EventCard({required this.event, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final eventColor = _getEventColor(event.type);

    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: AppTheme.darkSurfaceElevated,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: eventColor.withOpacity(0.3),
            width: 1,
          ),
        ),
        child: Row(
          children: [
            Container(
              width: 4,
              height: 48,
              decoration: BoxDecoration(
                color: eventColor,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    event.title,
                    style: context.textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  if (event.description?.isNotEmpty ?? false) ...[
                    const SizedBox(height: 4),
                    Text(
                      event.description!,
                      style: context.textTheme.bodySmall?.copyWith(
                        color: AppTheme.textSecondaryDark,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Icon(
                        Icons.access_time_rounded,
                        size: 14,
                        color: AppTheme.textTertiaryDark,
                      ),
                      const SizedBox(width: 4),
                      Text(
                        event.isAllDay
                            ? 'All day'
                            : '${event.startTime.formattedTime} - ${event.endTime.formattedTime}',
                        style: context.textTheme.labelSmall?.copyWith(
                          color: AppTheme.textTertiaryDark,
                        ),
                      ),
                      if (event.location?.isNotEmpty ?? false) ...[
                        const SizedBox(width: 12),
                        Icon(
                          Icons.location_on_rounded,
                          size: 14,
                          color: AppTheme.textTertiaryDark,
                        ),
                        const SizedBox(width: 4),
                        Text(
                          event.location!,
                          style: context.textTheme.labelSmall?.copyWith(
                            color: AppTheme.textTertiaryDark,
                          ),
                        ),
                      ],
                    ],
                  ),
                ],
              ),
            ),
            if (event.isHappeningNow)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                decoration: BoxDecoration(
                  color: eventColor.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text(
                  'Now',
                  style: context.textTheme.labelSmall?.copyWith(
                    color: eventColor,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Color _getEventColor(EventType type) {
    switch (type) {
      case EventType.work:
        return AppTheme.electricBlue;
      case EventType.meeting:
        return AppTheme.deepPurple;
      case EventType.personal:
        return AppTheme.accentEmerald;
      case EventType.reminder:
        return AppTheme.accentAmber;
      case EventType.focus:
        return AppTheme.accentRose;
      default:
        return AppTheme.textSecondaryDark;
    }
  }
}

class _EmptyEventsState extends StatelessWidget {
  final DateTime date;

  const _EmptyEventsState({required this.date});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(48),
      child: Center(
        child: Column(
          children: [
            Container(
              width: 64,
              height: 64,
              decoration: BoxDecoration(
                color: AppTheme.electricBlue.withOpacity(0.1),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Icon(
                Icons.event_available_rounded,
                size: 28,
                color: AppTheme.electricBlue.withOpacity(0.5),
              ),
            ),
            const SizedBox(height: 16),
            Text(
              'No events',
              style: context.textTheme.titleMedium,
            ),
            const SizedBox(height: 4),
            Text(
              'Your day is clear. Time to focus!',
              style: context.textTheme.bodySmall?.copyWith(
                color: AppTheme.textSecondaryDark,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
