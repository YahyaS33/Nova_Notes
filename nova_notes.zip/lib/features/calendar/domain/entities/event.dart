import 'package:equatable/equatable.dart';

/// Calendar Event Entity
class CalendarEvent extends Equatable {
  final String id;
  final String title;
  final String? description;
  final DateTime startTime;
  final DateTime endTime;
  final bool isAllDay;
  final String? location;
  final EventType type;
  final String? color;
  final List<String> attendees;
  final String? recurrenceRule;
  final String? reminderMinutes;
  final bool isRecurring;
  final String? noteId;
  final String? taskId;
  final bool isOffline;

  const CalendarEvent({
    required this.id,
    required this.title,
    this.description,
    required this.startTime,
    required this.endTime,
    this.isAllDay = false,
    this.location,
    this.type = EventType.personal,
    this.color,
    this.attendees = const [],
    this.recurrenceRule,
    this.reminderMinutes,
    this.isRecurring = false,
    this.noteId,
    this.taskId,
    this.isOffline = false,
  });

  Duration get duration => endTime.difference(startTime);

  bool get isHappeningNow {
    final now = DateTime.now();
    return now.isAfter(startTime) && now.isBefore(endTime);
  }

  @override
  List<Object?> get props => [
    id, title, description, startTime, endTime, isAllDay,
    location, type, color, attendees, recurrenceRule,
    reminderMinutes, isRecurring, noteId, taskId, isOffline,
  ];
}

enum EventType {
  personal,
  work,
  meeting,
  reminder,
  focus,
  birthday,
  holiday,
  custom,
}
