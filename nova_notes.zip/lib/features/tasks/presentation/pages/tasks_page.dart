import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../../../../core/constants/app_constants.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/utils/extensions.dart';
import '../../domain/entities/task.dart';
import '../bloc/tasks_bloc.dart';

/// Tasks Page - Smart Task Management with Kanban
class TasksPage extends StatefulWidget {
  const TasksPage({super.key});

  @override
  State<TasksPage> createState() => _TasksPageState();
}

class _TasksPageState extends State<TasksPage>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  TaskStatus _filterStatus = TaskStatus.todo;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
    _tabController.addListener(() {
      setState(() {
        _filterStatus = TaskStatus.values[_tabController.index];
      });
    });
    context.read<TasksBloc>().add(const LoadTasks());
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: context.theme.scaffoldBackgroundColor,
      body: NestedScrollView(
        physics: const BouncingScrollPhysics(),
        headerSliverBuilder: (context, innerBoxIsScrolled) => [
          SliverToBoxAdapter(
            child: Padding(
              padding: EdgeInsets.only(
                left: 24,
                right: 24,
                top: MediaQuery.of(context).padding.top + 16,
                bottom: 8,
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Tasks',
                    style: context.textTheme.displayMedium?.copyWith(
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  Row(
                    children: [
                      _IconButton(
                        icon: Icons.filter_list_rounded,
                        onTap: () => _showFilterSheet(context),
                      ),
                      const SizedBox(width: 8),
                      _IconButton(
                        icon: Icons.add_rounded,
                        onTap: () => _showAddTaskDialog(context),
                        isPrimary: true,
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: _TaskStatsBar(),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
              child: TabBar(
                controller: _tabController,
                isScrollable: true,
                tabAlignment: TabAlignment.start,
                indicator: BoxDecoration(
                  gradient: AppTheme.primaryGradient,
                  borderRadius: BorderRadius.circular(12),
                ),
                indicatorSize: TabBarIndicatorSize.tab,
                indicatorPadding: const EdgeInsets.symmetric(vertical: 4),
                labelColor: Colors.white,
                unselectedLabelColor: AppTheme.textSecondaryDark,
                labelStyle: context.textTheme.labelLarge?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
                unselectedLabelStyle: context.textTheme.labelLarge,
                dividerColor: Colors.transparent,
                tabs: const [
                  Tab(text: 'To Do'),
                  Tab(text: 'In Progress'),
                  Tab(text: 'Completed'),
                  Tab(text: 'All'),
                ],
              ),
            ),
          ),
        ],
        body: TabBarView(
          controller: _tabController,
          physics: const BouncingScrollPhysics(),
          children: [
            _TaskListView(status: TaskStatus.todo),
            _TaskListView(status: TaskStatus.inProgress),
            _TaskListView(status: TaskStatus.completed),
            _TaskListView(),
          ],
        ),
      ),
    );
  }

  void _showFilterSheet(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        decoration: BoxDecoration(
          color: context.colors.surface,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
        ),
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: context.colors.onSurface.withOpacity(0.2),
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(height: 24),
            Text('Filter & Sort', style: context.textTheme.titleLarge),
            const SizedBox(height: 16),
            Text('Priority', style: context.textTheme.labelLarge),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              children: TaskPriority.values.map((p) => _PriorityChip(priority: p)).toList(),
            ),
            const SizedBox(height: 24),
            Text('Sort by', style: context.textTheme.labelLarge),
            const SizedBox(height: 8),
            _SortOption(icon: Icons.calendar_today_rounded, label: 'Due date'),
            _SortOption(icon: Icons.flag_rounded, label: 'Priority'),
            _SortOption(icon: Icons.access_time_rounded, label: 'Created'),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }

  void _showAddTaskDialog(BuildContext context) {
    final titleController = TextEditingController();
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: context.colors.surface,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text('New Task', style: context.textTheme.titleLarge),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: titleController,
              autofocus: true,
              decoration: InputDecoration(
                hintText: 'What needs to be done?',
                filled: true,
                fillColor: context.colors.surfaceContainerHighest,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                _QuickActionChip(
                  icon: Icons.flag_rounded,
                  label: 'Priority',
                  color: AppTheme.accentAmber,
                ),
                const SizedBox(width: 8),
                _QuickActionChip(
                  icon: Icons.calendar_today_rounded,
                  label: 'Due date',
                  color: AppTheme.electricBlue,
                ),
                const SizedBox(width: 8),
                _QuickActionChip(
                  icon: Icons.label_rounded,
                  label: 'Tag',
                  color: AppTheme.deepPurple,
                ),
              ],
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () {
              if (titleController.text.isNotEmpty) {
                // Create task
                Navigator.pop(context);
              }
            },
            child: const Text('Add Task'),
          ),
        ],
      ),
    );
  }
}

class _TaskListView extends StatelessWidget {
  final TaskStatus? status;

  const _TaskListView({this.status});

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<TasksBloc, TasksState>(
      builder: (context, state) {
        if (state is TasksLoading) {
          return const Center(child: CircularProgressIndicator());
        }

        if (state is TasksLoaded) {
          var tasks = state.tasks;
          if (status != null) {
            tasks = tasks.where((t) => t.status == status).toList();
          }

          if (tasks.isEmpty) {
            return _EmptyTasksState(status: status);
          }

          return ListView.builder(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
            physics: const BouncingScrollPhysics(),
            itemCount: tasks.length,
            itemBuilder: (context, index) {
              return _TaskCard(
                task: tasks[index],
                onTap: () {},
                onComplete: () {
                  context.read<TasksBloc>().add(ToggleTaskStatus(tasks[index].id));
                },
              ).animate()
                .fadeIn(delay: (index * 50).ms, duration: 300.ms)
                .slideY(begin: 0.1, end: 0, duration: 300.ms);
            },
          );
        }

        return const SizedBox.shrink();
      },
    );
  }
}

class _TaskCard extends StatelessWidget {
  final Task task;
  final VoidCallback onTap;
  final VoidCallback onComplete;

  const _TaskCard({
    required this.task,
    required this.onTap,
    required this.onComplete,
  });

  @override
  Widget build(BuildContext context) {
    final priorityColor = _getPriorityColor(task.priority);
    final isCompleted = task.status == TaskStatus.completed;

    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: isCompleted
              ? AppTheme.darkSurfaceElevated.withOpacity(0.5)
              : AppTheme.darkSurfaceElevated,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: isCompleted
                ? AppTheme.darkBorder.withOpacity(0.3)
                : priorityColor.withOpacity(0.3),
          ),
        ),
        child: Row(
          children: [
            GestureDetector(
              onTap: onComplete,
              child: Container(
                width: 28,
                height: 28,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: isCompleted ? AppTheme.success : priorityColor,
                    width: 2,
                  ),
                  color: isCompleted ? AppTheme.success.withOpacity(0.2) : null,
                ),
                child: isCompleted
                    ? const Icon(Icons.check, size: 16, color: AppTheme.success)
                    : null,
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    task.title,
                    style: context.textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.w600,
                      decoration: isCompleted ? TextDecoration.lineThrough : null,
                      color: isCompleted ? AppTheme.textTertiaryDark : null,
                    ),
                  ),
                  if (task.description?.isNotEmpty ?? false) ...[
                    const SizedBox(height: 4),
                    Text(
                      task.description!,
                      style: context.textTheme.bodySmall?.copyWith(
                        color: AppTheme.textSecondaryDark,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      _PriorityBadge(priority: task.priority),
                      if (task.dueDate != null) ...[
                        const SizedBox(width: 8),
                        _DueDateBadge(
                          date: task.dueDate!,
                          isOverdue: task.isOverdue,
                        ),
                      ],
                      if (task.tags.isNotEmpty) ...[
                        const SizedBox(width: 8),
                        ...task.tags.take(2).map((tag) => _TagBadge(label: tag)),
                      ],
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Color _getPriorityColor(TaskPriority priority) {
    switch (priority) {
      case TaskPriority.urgent:
        return AppTheme.error;
      case TaskPriority.high:
        return AppTheme.accentAmber;
      case TaskPriority.medium:
        return AppTheme.electricBlue;
      case TaskPriority.low:
        return AppTheme.accentEmerald;
      default:
        return AppTheme.textTertiaryDark;
    }
  }
}

class _PriorityBadge extends StatelessWidget {
  final TaskPriority priority;

  const _PriorityBadge({required this.priority});

  @override
  Widget build(BuildContext context) {
    final color = _getColor();
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: color.withOpacity(0.15),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text(
        priority.name.toUpperCase(),
        style: context.textTheme.labelSmall?.copyWith(
          color: color,
          fontWeight: FontWeight.w700,
          fontSize: 10,
        ),
      ),
    );
  }

  Color _getColor() {
    switch (priority) {
      case TaskPriority.urgent:
        return AppTheme.error;
      case TaskPriority.high:
        return AppTheme.accentAmber;
      case TaskPriority.medium:
        return AppTheme.electricBlue;
      case TaskPriority.low:
        return AppTheme.accentEmerald;
      default:
        return AppTheme.textTertiaryDark;
    }
  }
}

class _DueDateBadge extends StatelessWidget {
  final DateTime date;
  final bool isOverdue;

  const _DueDateBadge({required this.date, this.isOverdue = false});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: isOverdue
            ? AppTheme.error.withOpacity(0.15)
            : AppTheme.electricBlue.withOpacity(0.15),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            isOverdue ? Icons.warning_rounded : Icons.access_time_rounded,
            size: 12,
            color: isOverdue ? AppTheme.error : AppTheme.electricBlue,
          ),
          const SizedBox(width: 4),
          Text(
            date.isToday ? 'Today' : date.formattedDate,
            style: context.textTheme.labelSmall?.copyWith(
              color: isOverdue ? AppTheme.error : AppTheme.electricBlue,
            ),
          ),
        ],
      ),
    );
  }
}

class _TagBadge extends StatelessWidget {
  final String label;

  const _TagBadge({required this.label});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(right: 4),
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: AppTheme.darkSurfaceGlass,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text(
        label,
        style: context.textTheme.labelSmall?.copyWith(
          color: AppTheme.textSecondaryDark,
        ),
      ),
    );
  }
}

class _TaskStatsBar extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
      child: Row(
        children: [
          _StatCard(label: 'To Do', value: '12', color: AppTheme.electricBlue),
          const SizedBox(width: 12),
          _StatCard(label: 'Done', value: '8', color: AppTheme.accentEmerald),
          const SizedBox(width: 12),
          _StatCard(label: 'Overdue', value: '2', color: AppTheme.error),
        ],
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  final String label;
  final String value;
  final Color color;

  const _StatCard({required this.label, required this.value, required this.color});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: color.withOpacity(0.2)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              value,
              style: context.textTheme.headlineMedium?.copyWith(
                color: color,
                fontWeight: FontWeight.w700,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              label,
              style: context.textTheme.labelMedium?.copyWith(
                color: color.withOpacity(0.8),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _EmptyTasksState extends StatelessWidget {
  final TaskStatus? status;

  const _EmptyTasksState({this.status});

  @override
  Widget build(BuildContext context) {
    final messages = {
      TaskStatus.todo: 'No tasks to do',
      TaskStatus.inProgress: 'Nothing in progress',
      TaskStatus.completed: 'No completed tasks yet',
    };

    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 64,
            height: 64,
            decoration: BoxDecoration(
              color: AppTheme.accentEmerald.withOpacity(0.1),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Icon(
              Icons.task_alt_rounded,
              size: 28,
              color: AppTheme.accentEmerald.withOpacity(0.5),
            ),
          ),
          const SizedBox(height: 16),
          Text(
            status != null ? messages[status] ?? 'No tasks' : 'No tasks yet',
            style: context.textTheme.titleMedium,
          ),
          const SizedBox(height: 4),
          Text(
            'Add a task to get started',
            style: context.textTheme.bodySmall?.copyWith(
              color: AppTheme.textSecondaryDark,
            ),
          ),
        ],
      ),
    );
  }
}

class _IconButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  final bool isPrimary;

  const _IconButton({
    required this.icon,
    required this.onTap,
    this.isPrimary = false,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 40,
        height: 40,
        decoration: BoxDecoration(
          gradient: isPrimary ? AppTheme.primaryGradient : null,
          color: isPrimary ? null : AppTheme.darkSurfaceElevated,
          borderRadius: BorderRadius.circular(12),
          border: isPrimary ? null : Border.all(color: AppTheme.darkBorder),
        ),
        child: Icon(
          icon,
          color: isPrimary ? Colors.white : null,
          size: 20,
        ),
      ),
    );
  }
}

class _QuickActionChip extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;

  const _QuickActionChip({
    required this.icon,
    required this.label,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 16, color: color),
          const SizedBox(width: 6),
          Text(
            label,
            style: context.textTheme.labelSmall?.copyWith(color: color),
          ),
        ],
      ),
    );
  }
}

class _PriorityChip extends StatelessWidget {
  final TaskPriority priority;

  const _PriorityChip({required this.priority});

  @override
  Widget build(BuildContext context) {
    final color = _getColor();
    return FilterChip(
      label: Text(priority.name.capitalize),
      selected: false,
      onSelected: (_) {},
      backgroundColor: color.withOpacity(0.1),
      selectedColor: color.withOpacity(0.2),
      labelStyle: context.textTheme.labelSmall?.copyWith(color: color),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(8),
        side: BorderSide(color: color.withOpacity(0.3)),
      ),
    );
  }

  Color _getColor() {
    switch (priority) {
      case TaskPriority.urgent:
        return AppTheme.error;
      case TaskPriority.high:
        return AppTheme.accentAmber;
      case TaskPriority.medium:
        return AppTheme.electricBlue;
      case TaskPriority.low:
        return AppTheme.accentEmerald;
      default:
        return AppTheme.textTertiaryDark;
    }
  }
}

class _SortOption extends StatelessWidget {
  final IconData icon;
  final String label;

  const _SortOption({required this.icon, required this.label});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: Icon(icon, size: 20, color: AppTheme.textSecondaryDark),
      title: Text(label, style: context.textTheme.bodyMedium),
      trailing: const Icon(Icons.check_rounded, size: 18, color: AppTheme.electricBlue),
      dense: true,
      contentPadding: EdgeInsets.zero,
    );
  }
}
