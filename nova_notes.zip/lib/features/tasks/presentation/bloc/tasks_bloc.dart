import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import '../../domain/entities/task.dart';

part 'tasks_event.dart';
part 'tasks_state.dart';

class TasksBloc extends Bloc<TasksEvent, TasksState> {
  TasksBloc() : super(TasksInitial()) {
    on<LoadTasks>(_onLoadTasks);
    on<CreateTask>(_onCreateTask);
    on<UpdateTask>(_onUpdateTask);
    on<DeleteTask>(_onDeleteTask);
    on<ToggleTaskStatus>(_onToggleTaskStatus);
  }

  Future<void> _onLoadTasks(LoadTasks event, Emitter<TasksState> emit) async {
    emit(TasksLoading());
    // TODO: Load from repository
    emit(const TasksLoaded(tasks: []));
  }

  Future<void> _onCreateTask(CreateTask event, Emitter<TasksState> emit) async {
    // TODO: Create task
  }

  Future<void> _onUpdateTask(UpdateTask event, Emitter<TasksState> emit) async {
    // TODO: Update task
  }

  Future<void> _onDeleteTask(DeleteTask event, Emitter<TasksState> emit) async {
    // TODO: Delete task
  }

  Future<void> _onToggleTaskStatus(
    ToggleTaskStatus event,
    Emitter<TasksState> emit,
  ) async {
    // TODO: Toggle status
  }
}
