part of 'tasks_bloc.dart';

abstract class TasksEvent extends Equatable {
  const TasksEvent();
  @override
  List<Object?> get props => [];
}

class LoadTasks extends TasksEvent {
  const LoadTasks();
}

class CreateTask extends TasksEvent {
  final Task task;
  const CreateTask(this.task);
  @override
  List<Object?> get props => [task];
}

class UpdateTask extends TasksEvent {
  final Task task;
  const UpdateTask(this.task);
  @override
  List<Object?> get props => [task];
}

class DeleteTask extends TasksEvent {
  final String id;
  const DeleteTask(this.id);
  @override
  List<Object?> get props => [id];
}

class ToggleTaskStatus extends TasksEvent {
  final String id;
  const ToggleTaskStatus(this.id);
  @override
  List<Object?> get props => [id];
}
