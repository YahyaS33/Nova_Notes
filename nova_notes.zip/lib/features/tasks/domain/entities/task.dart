import 'package:equatable/equatable.dart';

/// Task Entity - Core business object
class Task extends Equatable {
  final String id;
  final String title;
  final String? description;
  final TaskPriority priority;
  final TaskStatus status;
  final DateTime? dueDate;
  final DateTime? reminderDate;
  final DateTime createdAt;
  final DateTime updatedAt;
  final String? projectId;
  final List<String> tags;
  final List<String> subtasks;
  final bool isRecurring;
  final RecurrenceRule? recurrenceRule;
  final int? estimatedMinutes;
  final int? actualMinutes;
  final String? color;
  final String? noteId; // Linked note
  final bool isOffline;

  const Task({
    required this.id,
    required this.title,
    this.description,
    this.priority = TaskPriority.medium,
    this.status = TaskStatus.todo,
    this.dueDate,
    this.reminderDate,
    required this.createdAt,
    required this.updatedAt,
    this.projectId,
    this.tags = const [],
    this.subtasks = const [],
    this.isRecurring = false,
    this.recurrenceRule,
    this.estimatedMinutes,
    this.actualMinutes,
    this.color,
    this.noteId,
    this.isOffline = false,
  });

  Task copyWith({
    String? id,
    String? title,
    String? description,
    TaskPriority? priority,
    TaskStatus? status,
    DateTime? dueDate,
    DateTime? reminderDate,
    DateTime? createdAt,
    DateTime? updatedAt,
    String? projectId,
    List<String>? tags,
    List<String>? subtasks,
    bool? isRecurring,
    RecurrenceRule? recurrenceRule,
    int? estimatedMinutes,
    int? actualMinutes,
    String? color,
    String? noteId,
    bool? isOffline,
  }) {
    return Task(
      id: id ?? this.id,
      title: title ?? this.title,
      description: description ?? this.description,
      priority: priority ?? this.priority,
      status: status ?? this.status,
      dueDate: dueDate ?? this.dueDate,
      reminderDate: reminderDate ?? this.reminderDate,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      projectId: projectId ?? this.projectId,
      tags: tags ?? this.tags,
      subtasks: subtasks ?? this.subtasks,
      isRecurring: isRecurring ?? this.isRecurring,
      recurrenceRule: recurrenceRule ?? this.recurrenceRule,
      estimatedMinutes: estimatedMinutes ?? this.estimatedMinutes,
      actualMinutes: actualMinutes ?? this.actualMinutes,
      color: color ?? this.color,
      noteId: noteId ?? this.noteId,
      isOffline: isOffline ?? this.isOffline,
    );
  }

  bool get isOverdue {
    if (dueDate == null || status == TaskStatus.completed) return false;
    return dueDate!.isBefore(DateTime.now());
  }

  bool get isDueToday {
    if (dueDate == null) return false;
    final now = DateTime.now();
    return dueDate!.year == now.year && 
           dueDate!.month == now.month && 
           dueDate!.day == now.day;
  }

  @override
  List<Object?> get props => [
    id, title, description, priority, status, dueDate, reminderDate,
    createdAt, updatedAt, projectId, tags, subtasks, isRecurring,
    recurrenceRule, estimatedMinutes, actualMinutes, color, noteId, isOffline,
  ];
}

enum TaskPriority { none, low, medium, high, urgent }

enum TaskStatus { todo, inProgress, completed, archived }

class RecurrenceRule extends Equatable {
  final RecurrenceType type;
  final int interval;
  final DateTime? endDate;
  final List<int>? daysOfWeek; // 1=Monday, 7=Sunday

  const RecurrenceRule({
    required this.type,
    this.interval = 1,
    this.endDate,
    this.daysOfWeek,
  });

  @override
  List<Object?> get props => [type, interval, endDate, daysOfWeek];
}

enum RecurrenceType { daily, weekly, monthly, yearly }

/// Project/Collection for tasks (Kanban board)
class Project extends Equatable {
  final String id;
  final String name;
  final String? description;
  final String? color;
  final DateTime createdAt;
  final int taskCount;
  final List<String> columns; // Kanban columns

  const Project({
    required this.id,
    required this.name,
    this.description,
    this.color,
    required this.createdAt,
    this.taskCount = 0,
    this.columns = const ['To Do', 'In Progress', 'Done'],
  });

  @override
  List<Object?> get props => [id, name, description, color, createdAt, taskCount, columns];
}
