import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/utils/extensions.dart';
import '../../../tasks/domain/entities/task.dart';

class UpcomingTasksSection extends StatelessWidget {
  final Function(Task) onTaskTap;
  final Function(Task) onComplete;

  const UpcomingTasksSection({
    super.key,
    required this.onTaskTap,
    required this.onComplete,
  });

  @override
  Widget build(BuildContext context) {
    // Demo tasks for UI
    final tasks = [
      Task(
        id: '1',
        title: 'Review architecture document',
        priority: TaskPriority.high,
        status: TaskStatus.todo,
        dueDate: DateTime.now().add(const Duration(hours: 2)),
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
      ),
      Task(
        id: '2',
        title: 'Team standup meeting',
        priority: TaskPriority.medium,
        status: TaskStatus.todo,
        dueDate: DateTime.now().add(const Duration(hours: 4)),
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
      ),
      Task(
        id: '3',
        title: 'Update documentation',
        priority: TaskPriority.low,
        status: TaskStatus.inProgress,
        dueDate: DateTime.now().add(const Duration(days: 1)),
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
      ),
    ];

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Upcoming Tasks',
                style: context.textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
              ),
              TextButton(
                onPressed: () {},
                child: Text(
                  'See all',
                  style: context.textTheme.labelLarge?.copyWith(
                    color: AppTheme.electricBlue,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          ...tasks.asMap().entries.map((entry) {
            final index = entry.key;
            final task = entry.value;
            return _TaskItem(
              task: task,
              onTap: () => onTaskTap(task),
              onComplete: () => onComplete(task),
            ).animate()
              .fadeIn(delay: (index * 100).ms, duration: 300.ms)
              .slideX(begin: 0.2, end: 0, duration: 300.ms);
          }).toList(),
        ],
      ),
    );
  }
}

class _TaskItem extends StatelessWidget {
  final Task task;
  final VoidCallback onTap;
  final VoidCallback onComplete;

  const _TaskItem({
    required this.task,
    required this.onTap,
    required this.onComplete,
  });

  @override
  Widget build(BuildContext context) {
    final priorityColor = _getPriorityColor(task.priority);

    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: AppTheme.darkSurfaceElevated,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: AppTheme.darkBorder.withOpacity(0.5),
          ),
        ),
        child: Row(
          children: [
            GestureDetector(
              onTap: onComplete,
              child: Container(
                width: 24,
                height: 24,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(color: priorityColor, width: 2),
                ),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    task.title,
                    style: context.textTheme.bodyMedium?.copyWith(
                      fontWeight: FontWeight.w500,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      Container(
                        width: 6,
                        height: 6,
                        decoration: BoxDecoration(
                          color: priorityColor,
                          shape: BoxShape.circle,
                        ),
                      ),
                      const SizedBox(width: 6),
                      Text(
                        task.priority.name.capitalize,
                        style: context.textTheme.labelSmall?.copyWith(
                          color: priorityColor,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Icon(
                        Icons.access_time_rounded,
                        size: 12,
                        color: AppTheme.textTertiaryDark,
                      ),
                      const SizedBox(width: 4),
                      Text(
                        task.dueDate?.formattedTime ?? 'No due date',
                        style: context.textTheme.labelSmall?.copyWith(
                          color: AppTheme.textTertiaryDark,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Color _getPriorityColor(TaskPriority priority) {
    switch (priority) {
      case TaskPriority.urgent:
        return AppTheme.error;
      case TaskPriority.high:
        return AppTheme.accentAmber;
      case TaskPriority.medium:
        return AppTheme.electricBlue;
      case TaskPriority.low:
        return AppTheme.accentEmerald;
      default:
        return AppTheme.textTertiaryDark;
    }
  }
}
