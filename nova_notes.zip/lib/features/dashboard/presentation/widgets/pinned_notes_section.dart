import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/utils/extensions.dart';
import '../../../notes/domain/entities/note.dart';
import '../../../notes/presentation/bloc/notes_bloc.dart';

/// Pinned notes section on dashboard
class PinnedNotesSection extends StatelessWidget {
  final Function(Note) onNoteTap;

  const PinnedNotesSection({super.key, required this.onNoteTap});

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<NotesBloc, NotesState>(
      builder: (context, state) {
        if (state is NotesLoaded) {
          final pinnedNotes = state.notes.where((n) => n.isPinned && !n.isArchived).toList();
          if (pinnedNotes.isEmpty) return const SizedBox.shrink();

          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(
                      Icons.push_pin_rounded,
                      size: 18,
                      color: AppTheme.accentAmber,
                    ),
                    const SizedBox(width: 8),
                    Text(
                      'Pinned',
                      style: context.textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                      decoration: BoxDecoration(
                        color: AppTheme.accentAmber.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text(
                        '${pinnedNotes.length}',
                        style: context.textTheme.labelSmall?.copyWith(
                          color: AppTheme.accentAmber,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                SizedBox(
                  height: 140,
                  child: ListView.builder(
                    scrollDirection: Axis.horizontal,
                    itemCount: pinnedNotes.length,
                    physics: const BouncingScrollPhysics(),
                    itemBuilder: (context, index) {
                      final note = pinnedNotes[index];
                      return _PinnedNoteCard(
                        note: note,
                        onTap: () => onNoteTap(note),
                      ).animate()
                        .fadeIn(delay: (index * 100).ms, duration: 300.ms)
                        .slideX(begin: 0.3, end: 0, duration: 300.ms);
                    },
                  ),
                ),
              ],
            ),
          );
        }
        return const SizedBox.shrink();
      },
    );
  }
}

class _PinnedNoteCard extends StatelessWidget {
  final Note note;
  final VoidCallback onTap;

  const _PinnedNoteCard({required this.note, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 220,
        margin: const EdgeInsets.only(right: 12),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              AppTheme.darkSurfaceElevated,
              AppTheme.darkSurfaceGlass,
            ],
          ),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: AppTheme.darkBorder.withOpacity(0.5),
          ),
          boxShadow: AppTheme.softShadow,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  Icons.push_pin_rounded,
                  size: 14,
                  color: AppTheme.accentAmber.withOpacity(0.8),
                ),
                const SizedBox(width: 6),
                Expanded(
                  child: Text(
                    note.title,
                    style: context.textTheme.titleSmall?.copyWith(
                      fontWeight: FontWeight.w600,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Expanded(
              child: Text(
                note.plainText ?? note.content,
                style: context.textTheme.bodySmall?.copyWith(
                  color: AppTheme.textSecondaryDark,
                ),
                maxLines: 3,
                overflow: TextOverflow.ellipsis,
              ),
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                if (note.tags.isNotEmpty) ...[
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: AppTheme.electricBlue.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(
                      note.tags.first,
                      style: context.textTheme.labelSmall?.copyWith(
                        color: AppTheme.electricBlue,
                      ),
                    ),
                  ),
                ],
                const Spacer(),
                Text(
                  note.updatedAt.relativeTime,
                  style: context.textTheme.labelSmall?.copyWith(
                    color: AppTheme.textTertiaryDark,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
