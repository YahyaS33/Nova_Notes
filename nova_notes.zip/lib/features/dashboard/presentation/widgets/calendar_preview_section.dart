import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/utils/extensions.dart';
import '../../../calendar/domain/entities/event.dart';

class CalendarPreviewSection extends StatelessWidget {
  final Function(CalendarEvent) onEventTap;

  const CalendarPreviewSection({super.key, required this.onEventTap});

  @override
  Widget build(BuildContext context) {
    final events = [
      CalendarEvent(
        id: '1',
        title: 'Design Review',
        startTime: DateTime.now().add(const Duration(hours: 1)),
        endTime: DateTime.now().add(const Duration(hours: 2)),
        type: EventType.meeting,
      ),
      CalendarEvent(
        id: '2',
        title: 'Focus Session',
        startTime: DateTime.now().add(const Duration(hours: 3)),
        endTime: DateTime.now().add(const Duration(hours: 4)),
        type: EventType.focus,
      ),
    ];

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Today's Schedule',
                style: context.textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
              ),
              TextButton(
                onPressed: () {},
                child: Text(
                  'Calendar',
                  style: context.textTheme.labelLarge?.copyWith(
                    color: AppTheme.electricBlue,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          ...events.asMap().entries.map((entry) {
            final index = entry.key;
            final event = entry.value;
            return _EventPreviewItem(
              event: event,
              onTap: () => onEventTap(event),
            ).animate()
              .fadeIn(delay: (index * 100).ms, duration: 300.ms)
              .slideX(begin: 0.2, end: 0, duration: 300.ms);
          }).toList(),
        ],
      ),
    );
  }
}

class _EventPreviewItem extends StatelessWidget {
  final CalendarEvent event;
  final VoidCallback onTap;

  const _EventPreviewItem({required this.event, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final eventColor = _getEventColor(event.type);

    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: AppTheme.darkSurfaceElevated,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: eventColor.withOpacity(0.3),
          ),
        ),
        child: Row(
          children: [
            Container(
              width: 4,
              height: 40,
              decoration: BoxDecoration(
                color: eventColor,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    event.title,
                    style: context.textTheme.bodyMedium?.copyWith(
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    '${event.startTime.formattedTime} - ${event.endTime.formattedTime}',
                    style: context.textTheme.labelSmall?.copyWith(
                      color: AppTheme.textTertiaryDark,
                    ),
                  ),
                ],
              ),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              decoration: BoxDecoration(
                color: eventColor.withOpacity(0.15),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Text(
                event.type.name.capitalize,
                style: context.textTheme.labelSmall?.copyWith(
                  color: eventColor,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Color _getEventColor(EventType type) {
    switch (type) {
      case EventType.work:
        return AppTheme.electricBlue;
      case EventType.meeting:
        return AppTheme.deepPurple;
      case EventType.focus:
        return AppTheme.accentRose;
      default:
        return AppTheme.textSecondaryDark;
    }
  }
}
