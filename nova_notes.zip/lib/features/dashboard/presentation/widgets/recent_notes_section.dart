import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/utils/extensions.dart';
import '../../../notes/domain/entities/note.dart';

class RecentNotesSection extends StatelessWidget {
  final Function(Note) onNoteTap;
  final VoidCallback onSeeAll;

  const RecentNotesSection({
    super.key,
    required this.onNoteTap,
    required this.onSeeAll,
  });

  @override
  Widget build(BuildContext context) {
    final notes = [
      Note(
        id: '1',
        title: 'Architecture Review Notes',
        content: 'Clean architecture principles...',
        plainText: 'Clean architecture principles for the Nova Notes app...',
        createdAt: DateTime.now().subtract(const Duration(hours: 2)),
        updatedAt: DateTime.now().subtract(const Duration(hours: 2)),
        tags: ['Architecture'],
      ),
      Note(
        id: '2',
        title: 'Meeting: Q2 Planning',
        content: 'Discussion points...',
        plainText: 'Discussion points for Q2 planning session...',
        createdAt: DateTime.now().subtract(const Duration(hours: 5)),
        updatedAt: DateTime.now().subtract(const Duration(hours: 5)),
        tags: ['Meeting', 'Planning'],
      ),
    ];

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Recent Notes',
                style: context.textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
              ),
              TextButton(
                onPressed: onSeeAll,
                child: Text(
                  'See all',
                  style: context.textTheme.labelLarge?.copyWith(
                    color: AppTheme.electricBlue,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          ...notes.asMap().entries.map((entry) {
            final index = entry.key;
            final note = entry.value;
            return _RecentNoteItem(
              note: note,
              onTap: () => onNoteTap(note),
            ).animate()
              .fadeIn(delay: (index * 100).ms, duration: 300.ms)
              .slideX(begin: 0.2, end: 0, duration: 300.ms);
          }).toList(),
        ],
      ),
    );
  }
}

class _RecentNoteItem extends StatelessWidget {
  final Note note;
  final VoidCallback onTap;

  const _RecentNoteItem({required this.note, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: AppTheme.darkSurfaceElevated,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: AppTheme.darkBorder.withOpacity(0.5),
          ),
        ),
        child: Row(
          children: [
            Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                color: AppTheme.electricBlue.withOpacity(0.15),
                borderRadius: BorderRadius.circular(14),
              ),
              child: const Icon(
                Icons.edit_note_rounded,
                color: AppTheme.electricBlue,
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    note.title,
                    style: context.textTheme.bodyMedium?.copyWith(
                      fontWeight: FontWeight.w600,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 4),
                  Text(
                    note.plainText ?? '',
                    style: context.textTheme.labelMedium?.copyWith(
                      color: AppTheme.textSecondaryDark,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 6),
                  Row(
                    children: [
                      ...note.tags.take(2).map((tag) => Container(
                        margin: const EdgeInsets.only(right: 6),
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: AppTheme.darkSurfaceGlass,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(
                          tag,
                          style: context.textTheme.labelSmall?.copyWith(
                            color: AppTheme.textSecondaryDark,
                          ),
                        ),
                      )).toList(),
                      const Spacer(),
                      Text(
                        note.updatedAt.relativeTime,
                        style: context.textTheme.labelSmall?.copyWith(
                          color: AppTheme.textTertiaryDark,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
