import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/utils/extensions.dart';

/// Premium dashboard header with greeting and date
class DashboardHeader extends StatelessWidget {
  final AnimationController animationController;

  const DashboardHeader({super.key, required this.animationController});

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();

    return Container(
      padding: EdgeInsets.only(
        left: 24,
        right: 24,
        top: MediaQuery.of(context).padding.top + 16,
        bottom: 24,
      ),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            AppTheme.darkSurface.withOpacity(0.5),
            Colors.transparent,
          ],
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      now.greeting,
                      style: context.textTheme.labelLarge?.copyWith(
                        color: AppTheme.textSecondaryDark,
                      ),
                    ).animate(controller: animationController)
                      .fadeIn(duration: 400.ms)
                      .slideX(begin: -0.2, end: 0, duration: 400.ms),
                    const SizedBox(height: 4),
                    Text(
                      'Alex', // TODO: Get from user profile
                      style: context.textTheme.displayMedium?.copyWith(
                        color: AppTheme.textPrimaryDark,
                        fontWeight: FontWeight.w700,
                      ),
                    ).animate(controller: animationController)
                      .fadeIn(delay: 100.ms, duration: 500.ms)
                      .slideX(begin: -0.2, end: 0, duration: 500.ms),
                  ],
                ),
              ),
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  gradient: AppTheme.primaryGradient,
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: AppTheme.glowShadow,
                ),
                child: const Icon(
                  Icons.person_rounded,
                  color: Colors.white,
                ),
              ).animate(controller: animationController)
                .scale(delay: 200.ms, duration: 400.ms),
            ],
          ),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            decoration: BoxDecoration(
              color: AppTheme.darkSurfaceElevated,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                color: AppTheme.darkBorder.withOpacity(0.5),
              ),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(
                  Icons.calendar_today_rounded,
                  size: 16,
                  color: AppTheme.electricBlue,
                ),
                const SizedBox(width: 8),
                Text(
                  now.formattedDate,
                  style: context.textTheme.labelLarge?.copyWith(
                    color: AppTheme.textSecondaryDark,
                  ),
                ),
                const SizedBox(width: 12),
                Container(
                  width: 4,
                  height: 4,
                  decoration: BoxDecoration(
                    color: AppTheme.textTertiaryDark,
                    shape: BoxShape.circle,
                  ),
                ),
                const SizedBox(width: 12),
                Text(
                  now.dayName,
                  style: context.textTheme.labelLarge?.copyWith(
                    color: AppTheme.textSecondaryDark,
                  ),
                ),
              ],
            ),
          ).animate(controller: animationController)
            .fadeIn(delay: 300.ms, duration: 400.ms)
            .slideY(begin: 0.2, end: 0, duration: 400.ms),
        ],
      ),
    );
  }
}
