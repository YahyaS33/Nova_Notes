import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/utils/extensions.dart';

class FocusPage extends StatefulWidget {
  const FocusPage({super.key});
  @override
  State<FocusPage> createState() => _FocusPageState();
}

class _FocusPageState extends State<FocusPage> with SingleTickerProviderStateMixin {
  late AnimationController _breathController;
  bool _isRunning = false;
  int _secondsRemaining = 25 * 60;
  int _totalSeconds = 25 * 60;
  int _sessionCount = 0;

  @override
  void initState() {
    super.initState();
    _breathController = AnimationController(vsync: this, duration: const Duration(seconds: 4));
  }

  @override
  void dispose() { _breathController.dispose(); super.dispose(); }

  String get _timerText {
    final minutes = (_secondsRemaining / 60).floor();
    final seconds = _secondsRemaining % 60;
    return '${minutes.toString().padLeft(2, '0')}:${seconds.toString().padLeft(2, '0')}';
  }

  double get _progress => _secondsRemaining / _totalSeconds;

  void _toggleTimer() {
    setState(() => _isRunning = !_isRunning);
    if (_isRunning) { _breathController.repeat(reverse: true); _startTimer(); }
    else { _breathController.stop(); }
  }

  void _startTimer() {
    Future.doWhile(() async {
      await Future.delayed(const Duration(seconds: 1));
      if (!_isRunning || !mounted) return false;
      setState(() {
        if (_secondsRemaining > 0) { _secondsRemaining--; }
        else { _isRunning = false; _sessionCount++; _breathController.stop(); }
      });
      return _isRunning && _secondsRemaining > 0;
    });
  }

  void _resetTimer() { setState(() { _isRunning = false; _secondsRemaining = _totalSeconds; }); _breathController.stop(); }
  void _setDuration(int minutes) { setState(() { _totalSeconds = minutes * 60; _secondsRemaining = _totalSeconds; _isRunning = false; }); _breathController.stop(); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.darkBackground,
      body: Stack(children: [
        AnimatedBuilder(
          animation: _breathController,
          builder: (context, child) => Container(
            decoration: BoxDecoration(
              gradient: RadialGradient(
                center: Alignment.center, radius: 0.8 + (_breathController.value * 0.2),
                colors: [AppTheme.electricBlue.withOpacity(0.05 + (_breathController.value * 0.05)), Colors.transparent],
              ),
            ),
          ),
        ),
        SafeArea(
          child: Column(children: [
            Padding(
              padding: const EdgeInsets.all(24),
              child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                GestureDetector(
                  onTap: () => Navigator.pop(context),
                  child: Container(width: 40, height: 40, decoration: BoxDecoration(color: AppTheme.darkSurfaceElevated, borderRadius: BorderRadius.circular(12)), child: const Icon(Icons.close_rounded, size: 20)),
                ),
                Text('Focus Mode', style: context.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w600)),
                Container(width: 40, height: 40, decoration: BoxDecoration(color: AppTheme.darkSurfaceElevated, borderRadius: BorderRadius.circular(12)), child: const Icon(Icons.settings_rounded, size: 20)),
              ]),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              decoration: BoxDecoration(color: AppTheme.darkSurfaceElevated, borderRadius: BorderRadius.circular(12)),
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                Icon(Icons.local_fire_department_rounded, size: 18, color: AppTheme.accentAmber),
                const SizedBox(width: 8),
                Text('$_sessionCount sessions today', style: context.textTheme.labelLarge?.copyWith(color: AppTheme.accentAmber)),
              ]),
            ),
            const Spacer(),
            AnimatedBuilder(
              animation: _breathController,
              builder: (context, child) => Container(
                width: 280, height: 280,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: RadialGradient(colors: [AppTheme.electricBlue.withOpacity(_isRunning ? 0.1 + (_breathController.value * 0.1) : 0.05), Colors.transparent]),
                  boxShadow: _isRunning ? [BoxShadow(color: AppTheme.electricBlue.withOpacity(0.1 + (_breathController.value * 0.2)), blurRadius: 60, spreadRadius: 10)] : null,
                ),
                child: Stack(alignment: Alignment.center, children: [
                  SizedBox(width: 240, height: 240, child: CircularProgressIndicator(
                    value: _progress, strokeWidth: 4, backgroundColor: AppTheme.darkBorder,
                    valueColor: AlwaysStoppedAnimation<Color>(AppTheme.electricBlue),
                  )),
                  Column(mainAxisSize: MainAxisSize.min, children: [
                    Text(_timerText, style: context.textTheme.displayLarge?.copyWith(fontWeight: FontWeight.w300, fontSize: 64, letterSpacing: 2)),
                    const SizedBox(height: 8),
                    Text(_isRunning ? 'Focusing...' : 'Ready to focus', style: context.textTheme.labelLarge?.copyWith(color: AppTheme.textSecondaryDark)),
                  ]),
                ]),
              ),
            ),
            const Spacer(),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24),
              child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                _DurationChip(minutes: 15, label: '15m', isSelected: _totalSeconds == 15 * 60, onTap: () => _setDuration(15)),
                const SizedBox(width: 12),
                _DurationChip(minutes: 25, label: '25m', isSelected: _totalSeconds == 25 * 60, onTap: () => _setDuration(25)),
                const SizedBox(width: 12),
                _DurationChip(minutes: 45, label: '45m', isSelected: _totalSeconds == 45 * 60, onTap: () => _setDuration(45)),
                const SizedBox(width: 12),
                _DurationChip(minutes: 60, label: '60m', isSelected: _totalSeconds == 60 * 60, onTap: () => _setDuration(60)),
              ]),
            ),
            const SizedBox(height: 32),
            Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              GestureDetector(
                onTap: _resetTimer,
                child: Container(width: 56, height: 56, decoration: BoxDecoration(color: AppTheme.darkSurfaceElevated, borderRadius: BorderRadius.circular(20), border: Border.all(color: AppTheme.darkBorder)), child: const Icon(Icons.replay_rounded, size: 24)),
              ),
              const SizedBox(width: 24),
              GestureDetector(
                onTap: _toggleTimer,
                child: Container(
                  width: 72, height: 72,
                  decoration: BoxDecoration(gradient: AppTheme.primaryGradient, borderRadius: BorderRadius.circular(24), boxShadow: AppTheme.glowShadow),
                  child: Icon(_isRunning ? Icons.pause_rounded : Icons.play_arrow_rounded, color: Colors.white, size: 32),
                ),
              ),
              const SizedBox(width: 24),
              GestureDetector(
                onTap: () {},
                child: Container(width: 56, height: 56, decoration: BoxDecoration(color: AppTheme.darkSurfaceElevated, borderRadius: BorderRadius.circular(20), border: Border.all(color: AppTheme.darkBorder)), child: const Icon(Icons.skip_next_rounded, size: 24)),
              ),
            ]),
            const SizedBox(height: 48),
          ]),
        ),
      ]),
    );
  }
}

class _DurationChip extends StatelessWidget {
  final int minutes; final String label; final bool isSelected; final VoidCallback onTap;
  const _DurationChip({required this.minutes, required this.label, required this.isSelected, required this.onTap});
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        decoration: BoxDecoration(
          color: isSelected ? AppTheme.electricBlue.withOpacity(0.2) : AppTheme.darkSurfaceElevated,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: isSelected ? AppTheme.electricBlue.withOpacity(0.5) : AppTheme.darkBorder),
        ),
        child: Text(label, style: context.textTheme.labelLarge?.copyWith(color: isSelected ? AppTheme.electricBlue : AppTheme.textSecondaryDark, fontWeight: isSelected ? FontWeight.w700 : FontWeight.w500)),
      ),
    );
  }
}
