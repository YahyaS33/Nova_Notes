import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../../../../core/constants/app_constants.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/utils/extensions.dart';
import '../../../notes/presentation/bloc/notes_bloc.dart';
import '../../../tasks/presentation/bloc/tasks_bloc.dart';
import '../../../calendar/presentation/bloc/calendar_bloc.dart';
import '../widgets/dashboard_header.dart';
import '../widgets/quick_actions_bar.dart';
import '../widgets/pinned_notes_section.dart';
import '../widgets/upcoming_tasks_section.dart';
import '../widgets/calendar_preview_section.dart';
import '../widgets/productivity_insights.dart';
import '../widgets/recent_notes_section.dart';

/// Premium Dashboard - The heart of Nova Notes
class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with SingleTickerProviderStateMixin {
  late AnimationController _animationController;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );
    _animationController.forward();

    // Load data
    context.read<NotesBloc>().add(const LoadNotes());
    context.read<TasksBloc>().add(const LoadTasks());
    context.read<CalendarBloc>().add(const LoadTodayEvents());
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: context.theme.scaffoldBackgroundColor,
      body: CustomScrollView(
        physics: const BouncingScrollPhysics(),
        slivers: [
          // App Bar with greeting
          SliverToBoxAdapter(
            child: DashboardHeader(
              animationController: _animationController,
            ),
          ),

          // Quick Actions
          SliverToBoxAdapter(
            child: QuickActionsBar(
              onNewNote: () => context.push(AppConstants.routeNoteEditor),
              onNewTask: () => _showQuickTaskDialog(context),
              onFocusMode: () => context.push(AppConstants.routeFocus),
              onSearch: () => context.push(AppConstants.routeSearch),
            ).animate()
              .fadeIn(delay: 200.ms, duration: 400.ms)
              .slideY(begin: 0.2, end: 0, duration: 400.ms),
          ),

          // Pinned Notes
          SliverToBoxAdapter(
            child: PinnedNotesSection(
              onNoteTap: (note) => context.push(
                '${AppConstants.routeNoteEditor}?id=${note.id}',
              ),
            ).animate()
              .fadeIn(delay: 300.ms, duration: 400.ms)
              .slideY(begin: 0.2, end: 0, duration: 400.ms),
          ),

          // Upcoming Tasks
          SliverToBoxAdapter(
            child: UpcomingTasksSection(
              onTaskTap: (task) => context.push(
                '${AppConstants.routeTaskDetail.replaceAll(':id', task.id)}',
              ),
              onComplete: (task) {
                context.read<TasksBloc>().add(ToggleTaskStatus(task.id));
              },
            ).animate()
              .fadeIn(delay: 400.ms, duration: 400.ms)
              .slideY(begin: 0.2, end: 0, duration: 400.ms),
          ),

          // Calendar Preview
          SliverToBoxAdapter(
            child: CalendarPreviewSection(
              onEventTap: (event) => context.push(AppConstants.routeCalendar),
            ).animate()
              .fadeIn(delay: 500.ms, duration: 400.ms)
              .slideY(begin: 0.2, end: 0, duration: 400.ms),
          ),

          // Productivity Insights
          SliverToBoxAdapter(
            child: ProductivityInsights(
              onViewDetails: () {},
            ).animate()
              .fadeIn(delay: 600.ms, duration: 400.ms)
              .slideY(begin: 0.2, end: 0, duration: 400.ms),
          ),

          // Recent Notes
          SliverToBoxAdapter(
            child: RecentNotesSection(
              onNoteTap: (note) => context.push(
                '${AppConstants.routeNoteEditor}?id=${note.id}',
              ),
              onSeeAll: () => context.go(AppConstants.routeNotes),
            ).animate()
              .fadeIn(delay: 700.ms, duration: 400.ms)
              .slideY(begin: 0.2, end: 0, duration: 400.ms),
          ),

          // Bottom padding
          const SliverToBoxAdapter(
            child: SizedBox(height: 32),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _showQuickAddSheet(context),
        icon: const Icon(Icons.add_rounded),
        label: const Text('Quick Add'),
        elevation: 4,
      ).animate()
        .scale(delay: 800.ms, duration: 300.ms),
    );
  }

  void _showQuickAddSheet(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        decoration: BoxDecoration(
          color: context.colors.surface,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
        ),
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: context.colors.onSurface.withOpacity(0.2),
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(height: 24),
            Text(
              'Quick Add',
              style: context.textTheme.headlineSmall,
            ),
            const SizedBox(height: 24),
            _QuickActionTile(
              icon: Icons.edit_note_rounded,
              title: 'New Note',
              subtitle: 'Capture your thoughts instantly',
              color: AppTheme.electricBlue,
              onTap: () {
                Navigator.pop(context);
                context.push(AppConstants.routeNoteEditor);
              },
            ),
            const SizedBox(height: 12),
            _QuickActionTile(
              icon: Icons.task_alt_rounded,
              title: 'New Task',
              subtitle: 'Add a task to your list',
              color: AppTheme.accentEmerald,
              onTap: () {
                Navigator.pop(context);
                _showQuickTaskDialog(context);
              },
            ),
            const SizedBox(height: 12),
            _QuickActionTile(
              icon: Icons.event_rounded,
              title: 'New Event',
              subtitle: 'Schedule something important',
              color: AppTheme.accentAmber,
              onTap: () {
                Navigator.pop(context);
                context.push(AppConstants.routeCalendar);
              },
            ),
            const SizedBox(height: 12),
            _QuickActionTile(
              icon: Icons.auto_awesome_rounded,
              title: 'Ask AI',
              subtitle: 'Get smart suggestions',
              color: AppTheme.deepPurple,
              onTap: () {
                Navigator.pop(context);
                context.push(AppConstants.routeAIAssistant);
              },
            ),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }

  void _showQuickTaskDialog(BuildContext context) {
    final controller = TextEditingController();
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: context.colors.surface,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text('Quick Task', style: context.textTheme.titleLarge),
        content: TextField(
          controller: controller,
          autofocus: true,
          decoration: InputDecoration(
            hintText: 'What needs to be done?',
            filled: true,
            fillColor: context.colors.surfaceContainerHighest,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide.none,
            ),
          ),
          onSubmitted: (value) {
            if (value.isNotEmpty) {
              // Create task
              Navigator.pop(context);
            }
          },
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () {
              if (controller.text.isNotEmpty) {
                // Create task
                Navigator.pop(context);
              }
            },
            child: const Text('Add'),
          ),
        ],
      ),
    );
  }
}

class _QuickActionTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final Color color;
  final VoidCallback onTap;

  const _QuickActionTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      onTap: onTap,
      leading: Container(
        width: 48,
        height: 48,
        decoration: BoxDecoration(
          color: color.withOpacity(0.15),
          borderRadius: BorderRadius.circular(14),
        ),
        child: Icon(icon, color: color),
      ),
      title: Text(title, style: context.textTheme.titleMedium),
      subtitle: Text(
        subtitle,
        style: context.textTheme.bodySmall?.copyWith(
          color: context.colors.onSurface.withOpacity(0.6),
        ),
      ),
      trailing: Icon(
        Icons.arrow_forward_ios_rounded,
        size: 16,
        color: context.colors.onSurface.withOpacity(0.4),
      ),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
    );
  }
}
