import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/utils/extensions.dart';

class AIAssistantPage extends StatefulWidget {
  const AIAssistantPage({super.key});
  @override
  State<AIAssistantPage> createState() => _AIAssistantPageState();
}

class _AIAssistantPageState extends State<AIAssistantPage> {
  final _messageController = TextEditingController();
  final List<AIChatMessage> _messages = [];
  bool _isTyping = false;

  @override
  void initState() {
    super.initState();
    _messages.add(AIChatMessage(
      text: "Hello! I'm Nova AI, your productivity assistant. I can help you summarize notes, extract tasks, plan your day, and analyze your productivity.",
      isUser: false,
      timestamp: DateTime.now(),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: context.theme.scaffoldBackgroundColor,
      body: Column(children: [
        Container(
          padding: EdgeInsets.only(
            left: 24, right: 24,
            top: MediaQuery.of(context).padding.top + 16,
            bottom: 16,
          ),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter, end: Alignment.bottomCenter,
              colors: [AppTheme.deepPurple.withOpacity(0.2), Colors.transparent],
            ),
          ),
          child: Row(children: [
            Container(
              width: 44, height: 44,
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [AppTheme.deepPurple, AppTheme.electricBlue]),
                borderRadius: BorderRadius.circular(14),
                boxShadow: [BoxShadow(color: AppTheme.deepPurple.withOpacity(0.3), blurRadius: 12, spreadRadius: 2)],
              ),
              child: const Icon(Icons.auto_awesome_rounded, color: Colors.white, size: 22),
            ),
            const SizedBox(width: 16),
            Expanded(child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Nova AI', style: context.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w700)),
                Text('Your productivity companion', style: context.textTheme.labelMedium?.copyWith(color: AppTheme.textSecondaryDark)),
              ],
            )),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              decoration: BoxDecoration(color: AppTheme.accentEmerald.withOpacity(0.15), borderRadius: BorderRadius.circular(10)),
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                Container(width: 6, height: 6, decoration: const BoxDecoration(color: AppTheme.accentEmerald, shape: BoxShape.circle)),
                const SizedBox(width: 6),
                Text('Online', style: context.textTheme.labelSmall?.copyWith(color: AppTheme.accentEmerald, fontWeight: FontWeight.w600)),
              ]),
            ),
          ]),
        ),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
          child: SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            physics: const BouncingScrollPhysics(),
            child: Row(children: [
              _QuickActionButton(icon: Icons.summarize_rounded, label: 'Summarize', color: AppTheme.electricBlue, onTap: () => _sendQuickAction('Summarize my recent notes')),
              const SizedBox(width: 10),
              _QuickActionButton(icon: Icons.task_alt_rounded, label: 'Extract Tasks', color: AppTheme.accentEmerald, onTap: () => _sendQuickAction('Extract tasks from my notes')),
              const SizedBox(width: 10),
              _QuickActionButton(icon: Icons.calendar_today_rounded, label: 'Plan Day', color: AppTheme.accentAmber, onTap: () => _sendQuickAction('Help me plan my day')),
              const SizedBox(width: 10),
              _QuickActionButton(icon: Icons.insights_rounded, label: 'Analyze', color: AppTheme.deepPurple, onTap: () => _sendQuickAction('Analyze my productivity')),
            ]),
          ),
        ),
        Expanded(
          child: ListView.builder(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
            reverse: true,
            physics: const BouncingScrollPhysics(),
            itemCount: _messages.length,
            itemBuilder: (context, index) {
              final message = _messages[_messages.length - 1 - index];
              return _ChatBubble(message: message).animate().fadeIn(duration: 300.ms).slideY(begin: 0.2, end: 0, duration: 300.ms);
            },
          ),
        ),
        if (_isTyping)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24),
            child: Row(children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                decoration: BoxDecoration(color: AppTheme.darkSurfaceElevated, borderRadius: BorderRadius.circular(16)),
                child: Row(mainAxisSize: MainAxisSize.min, children: [
                  _Dot(delay: 0), const SizedBox(width: 4), _Dot(delay: 200), const SizedBox(width: 4), _Dot(delay: 400),
                ]),
              ),
            ]),
          ),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: AppTheme.darkSurfaceElevated,
            border: Border(top: BorderSide(color: AppTheme.darkBorder.withOpacity(0.5))),
          ),
          child: SafeArea(
            child: Row(children: [
              Expanded(
                child: TextField(
                  controller: _messageController,
                  decoration: InputDecoration(
                    hintText: 'Ask Nova AI anything...',
                    filled: true,
                    fillColor: AppTheme.darkSurfaceGlass,
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
                    contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                  ),
                  onSubmitted: _sendMessage,
                ),
              ),
              const SizedBox(width: 12),
              GestureDetector(
                onTap: () => _sendMessage(_messageController.text),
                child: Container(
                  width: 48, height: 48,
                  decoration: BoxDecoration(gradient: AppTheme.primaryGradient, borderRadius: BorderRadius.circular(16), boxShadow: AppTheme.glowShadow),
                  child: const Icon(Icons.send_rounded, color: Colors.white),
                ),
              ),
            ]),
          ),
        ),
      ]),
    );
  }

  void _sendQuickAction(String text) => _sendMessage(text);

  void _sendMessage(String text) {
    if (text.trim().isEmpty) return;
    setState(() {
      _messages.add(AIChatMessage(text: text, isUser: true, timestamp: DateTime.now()));
      _messageController.clear();
      _isTyping = true;
    });
    Future.delayed(const Duration(seconds: 2), () {
      if (!mounted) return;
      setState(() {
        _isTyping = false;
        _messages.add(AIChatMessage(text: _generateResponse(text), isUser: false, timestamp: DateTime.now()));
      });
    });
  }

  String _generateResponse(String input) {
    if (input.contains('summarize')) return 'Based on your recent notes, here's a summary:

• You've been working on the Nova Notes app architecture
• 3 notes about Clean Architecture patterns
• 2 meeting notes from this week

Key insight: Focus on the data layer. Consider spending more time on UI/UX next.';
    if (input.contains('task') || input.contains('extract')) return 'I found 5 potential tasks in your notes:

1. Implement Firebase Auth integration
2. Create offline sync mechanism
3. Design the note editor UI
4. Add markdown support
5. Set up CI/CD pipeline

Would you like me to add these to your task list?';
    if (input.contains('plan') || input.contains('day')) return 'Here's your optimized daily plan:

Morning (9:00 - 12:00)
• Deep work: Architecture review
• 2 Pomodoro sessions

Afternoon (13:00 - 17:00)
• Team standup at 14:00
• Code review session
• UI component development

Evening (17:00+)
• Documentation updates
• Planning for tomorrow

You have 3 tasks due today and 1 meeting at 14:00.';
    return 'I'm here to help with your productivity! I can summarize notes, extract tasks, plan your schedule, or analyze your work patterns. What would you like to explore?';
  }
}

class AIChatMessage {
  final String text; final bool isUser; final DateTime timestamp;
  AIChatMessage({required this.text, required this.isUser, required this.timestamp});
}

class _ChatBubble extends StatelessWidget {
  final AIChatMessage message;
  const _ChatBubble({required this.message});
  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: message.isUser ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        constraints: BoxConstraints(maxWidth: context.screenWidth * 0.75),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        decoration: BoxDecoration(
          gradient: message.isUser ? AppTheme.primaryGradient : null,
          color: message.isUser ? null : AppTheme.darkSurfaceElevated,
          borderRadius: BorderRadius.circular(16).copyWith(
            bottomRight: message.isUser ? const Radius.circular(4) : null,
            bottomLeft: !message.isUser ? const Radius.circular(4) : null,
          ),
          border: message.isUser ? null : Border.all(color: AppTheme.darkBorder.withOpacity(0.5)),
        ),
        child: Text(message.text, style: context.textTheme.bodyMedium?.copyWith(color: message.isUser ? Colors.white : AppTheme.textPrimaryDark)),
      ),
    );
  }
}

class _QuickActionButton extends StatelessWidget {
  final IconData icon; final String label; final Color color; final VoidCallback onTap;
  const _QuickActionButton({required this.icon, required this.label, required this.color, required this.onTap});
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        decoration: BoxDecoration(color: color.withOpacity(0.1), borderRadius: BorderRadius.circular(12), border: Border.all(color: color.withOpacity(0.2))),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(icon, size: 18, color: color), const SizedBox(width: 8),
          Text(label, style: context.textTheme.labelMedium?.copyWith(color: color, fontWeight: FontWeight.w600)),
        ]),
      ),
    );
  }
}

class _Dot extends StatefulWidget {
  final int delay;
  const _Dot({required this.delay});
  @override
  State<_Dot> createState() => _DotState();
}

class _DotState extends State<_Dot> with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  @override
  void initState() {
    super.initState();
    _controller = AnimationController(vsync: this, duration: const Duration(milliseconds: 600));
    Future.delayed(Duration(milliseconds: widget.delay), () { if (mounted) _controller.repeat(reverse: true); });
  }
  @override
  void dispose() { _controller.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, child) => Container(
        width: 6, height: 6,
        decoration: BoxDecoration(color: AppTheme.textSecondaryDark.withOpacity(0.3 + (_controller.value * 0.7)), shape: BoxShape.circle),
      ),
    );
  }
}
