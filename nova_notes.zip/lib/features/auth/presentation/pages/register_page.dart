import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:go_router/go_router.dart';
import '../../../../core/constants/app_constants.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/utils/extensions.dart';

class RegisterPage extends StatefulWidget {
  const RegisterPage({super.key});
  @override
  State<RegisterPage> createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage> {
  final _nameController = TextEditingController();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  bool _isLoading = false;
  bool _obscurePassword = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.darkBackground,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          physics: const BouncingScrollPhysics(),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 40),
              GestureDetector(
                onTap: () => Navigator.pop(context),
                child: Container(
                  width: 44, height: 44,
                  decoration: BoxDecoration(color: AppTheme.darkSurfaceElevated, borderRadius: BorderRadius.circular(14), border: Border.all(color: AppTheme.darkBorder)),
                  child: const Icon(Icons.arrow_back_rounded, size: 20),
                ),
              ).animate().fadeIn(duration: 300.ms).slideX(begin: -0.2, end: 0, duration: 300.ms),
              const SizedBox(height: 40),
              Text('Create account', style: context.textTheme.displayMedium?.copyWith(fontWeight: FontWeight.w700))
                .animate().fadeIn(delay: 100.ms, duration: 500.ms).slideY(begin: 0.2, end: 0, delay: 100.ms, duration: 500.ms),
              const SizedBox(height: 8),
              Text('Start your productivity journey today', style: context.textTheme.bodyLarge?.copyWith(color: AppTheme.textSecondaryDark))
                .animate().fadeIn(delay: 200.ms, duration: 500.ms).slideY(begin: 0.2, end: 0, delay: 200.ms, duration: 500.ms),
              const SizedBox(height: 40),
              _buildTextField(controller: _nameController, hint: 'Full name', icon: Icons.person_rounded)
                .animate().fadeIn(delay: 300.ms, duration: 400.ms).slideY(begin: 0.2, end: 0, delay: 300.ms, duration: 400.ms),
              const SizedBox(height: 16),
              _buildTextField(controller: _emailController, hint: 'Email address', icon: Icons.email_rounded, keyboardType: TextInputType.emailAddress)
                .animate().fadeIn(delay: 400.ms, duration: 400.ms).slideY(begin: 0.2, end: 0, delay: 400.ms, duration: 400.ms),
              const SizedBox(height: 16),
              _buildTextField(
                controller: _passwordController, hint: 'Password', icon: Icons.lock_rounded,
                obscureText: _obscurePassword,
                suffixIcon: IconButton(
                  icon: Icon(_obscurePassword ? Icons.visibility_off_rounded : Icons.visibility_rounded, size: 20, color: AppTheme.textTertiaryDark),
                  onPressed: () => setState(() => _obscurePassword = !_obscurePassword),
                ),
              ).animate().fadeIn(delay: 500.ms, duration: 400.ms).slideY(begin: 0.2, end: 0, delay: 500.ms, duration: 400.ms),
              const SizedBox(height: 24),
              SizedBox(
                width: double.infinity,
                child: FilledButton(
                  onPressed: _isLoading ? null : _signUp,
                  style: FilledButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 16), backgroundColor: AppTheme.electricBlue, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
                  child: _isLoading
                    ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                    : Text('Create Account', style: context.textTheme.labelLarge?.copyWith(color: Colors.white, fontWeight: FontWeight.w600)),
                ),
              ).animate().fadeIn(delay: 600.ms, duration: 400.ms).slideY(begin: 0.2, end: 0, delay: 600.ms, duration: 400.ms),
              const SizedBox(height: 24),
              Row(children: [
                Expanded(child: Divider(color: AppTheme.darkBorder)),
                Padding(padding: const EdgeInsets.symmetric(horizontal: 16), child: Text('or continue with', style: context.textTheme.labelMedium?.copyWith(color: AppTheme.textTertiaryDark))),
                Expanded(child: Divider(color: AppTheme.darkBorder)),
              ]).animate().fadeIn(delay: 700.ms, duration: 400.ms),
              const SizedBox(height: 24),
              Row(children: [
                Expanded(child: _SocialButton(icon: Icons.g_mobiledata_rounded, label: 'Google', onTap: () {})),
                const SizedBox(width: 12),
                Expanded(child: _SocialButton(icon: Icons.apple_rounded, label: 'Apple', onTap: () {})),
              ]).animate().fadeIn(delay: 800.ms, duration: 400.ms).slideY(begin: 0.2, end: 0, delay: 800.ms, duration: 400.ms),
              const SizedBox(height: 40),
              Center(
                child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Text('Already have an account? ', style: context.textTheme.bodyMedium?.copyWith(color: AppTheme.textSecondaryDark)),
                  GestureDetector(
                    onTap: () => context.push(AppConstants.routeLogin),
                    child: Text('Sign In', style: context.textTheme.bodyMedium?.copyWith(color: AppTheme.electricBlue, fontWeight: FontWeight.w600)),
                  ),
                ]),
              ).animate().fadeIn(delay: 900.ms, duration: 400.ms),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTextField({required TextEditingController controller, required String hint, required IconData icon, TextInputType? keyboardType, bool obscureText = false, Widget? suffixIcon}) {
    return TextField(controller: controller, keyboardType: keyboardType, obscureText: obscureText,
      decoration: InputDecoration(hintText: hint, prefixIcon: Icon(icon, size: 20, color: AppTheme.textTertiaryDark), suffixIcon: suffixIcon));
  }

  void _signUp() {
    setState(() => _isLoading = true);
    Future.delayed(const Duration(seconds: 2), () {
      if (mounted) { setState(() => _isLoading = false); context.go(AppConstants.routeDashboard); }
    });
  }
}

class _SocialButton extends StatelessWidget {
  final IconData icon; final String label; final VoidCallback onTap;
  const _SocialButton({required this.icon, required this.label, required this.onTap});
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(color: AppTheme.darkSurfaceElevated, borderRadius: BorderRadius.circular(16), border: Border.all(color: AppTheme.darkBorder)),
        child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(icon, size: 22), const SizedBox(width: 8), Text(label, style: context.textTheme.labelLarge?.copyWith(fontWeight: FontWeight.w600))]),
      ),
    );
  }
}
