import 'package:equatable/equatable.dart';

/// User Entity
class User extends Equatable {
  final String id;
  final String email;
  final String? displayName;
  final String? photoUrl;
  final DateTime createdAt;
  final DateTime? lastLoginAt;
  final UserPreferences preferences;
  final UserSubscription subscription;

  const User({
    required this.id,
    required this.email,
    this.displayName,
    this.photoUrl,
    required this.createdAt,
    this.lastLoginAt,
    this.preferences = const UserPreferences(),
    this.subscription = const UserSubscription(),
  });

  @override
  List<Object?> get props => [
    id, email, displayName, photoUrl, createdAt, 
    lastLoginAt, preferences, subscription,
  ];
}

class UserPreferences extends Equatable {
  final bool darkMode;
  final bool compactView;
  final bool notificationsEnabled;
  final bool aiSuggestionsEnabled;
  final String? defaultView;
  final String? language;

  const UserPreferences({
    this.darkMode = true,
    this.compactView = false,
    this.notificationsEnabled = true,
    this.aiSuggestionsEnabled = true,
    this.defaultView = 'dashboard',
    this.language = 'en',
  });

  @override
  List<Object?> get props => [
    darkMode, compactView, notificationsEnabled, 
    aiSuggestionsEnabled, defaultView, language,
  ];
}

class UserSubscription extends Equatable {
  final SubscriptionTier tier;
  final DateTime? expiresAt;
  final bool isActive;

  const UserSubscription({
    this.tier = SubscriptionTier.free,
    this.expiresAt,
    this.isActive = true,
  });

  @override
  List<Object?> get props => [tier, expiresAt, isActive];
}

enum SubscriptionTier { free, pro, team, enterprise }
