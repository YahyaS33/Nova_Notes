# Changelog

All notable changes to Nova Notes will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.0] - 2026-05-24

### Added
- Initial release of Nova Notes
- Smart Notes system with rich editor and markdown support
- Calendar with day/week/month views and agenda layout
- Task management with priorities, due dates, and Kanban board
- Dashboard with productivity overview and quick actions
- AI Assistant for summaries, task extraction, and planning
- Focus mode with Pomodoro timer
- Offline-first architecture with auto-sync
- Firebase Authentication (Email, Google, Apple)
- Firestore cloud sync
- Push notifications for reminders
- Dark mode first design system
- Cross-platform support (iOS, Android, Web)
- Clean Architecture implementation
- BLoC state management
- Comprehensive test suite structure

### Security
- Secure local storage for sensitive data
- Firebase Auth with secure token handling
- Input validation and sanitization

## [Unreleased]

### Planned
- Google Calendar sync
- Apple Calendar sync
- Biometric authentication
- Home screen widgets
- Deep linking support
- Share extensions
- Team collaboration features
- Desktop support (macOS, Windows, Linux)
